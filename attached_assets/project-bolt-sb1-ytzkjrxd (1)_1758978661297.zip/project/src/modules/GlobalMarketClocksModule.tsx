import React, { useState, useEffect } from 'react';
import { Clock, Globe } from 'lucide-react';

interface MarketTime {
  city: string;
  timezone: string;
  marketOpen: string;
  marketClose: string;
  afterHoursOpen?: string;
  afterHoursClose?: string;
  flag: string;
  primaryColorHex: string;
  exchange: string;
}

interface GlobalMarketClocksModuleProps {
  /** Show the module header */
  showHeader?: boolean;
  /** Custom title for the module */
  title?: string;
  /** Custom subtitle for the module */
  subtitle?: string;
  /** Number of clocks to display */
  maxClocks?: number;
  /** Show analog clocks vs digital only */
  showAnalogClocks?: boolean;
  /** Show market session legend */
  showLegend?: boolean;
  /** Compact mode for smaller displays */
  compact?: boolean;
  /** Custom CSS classes */
  className?: string;
  /** Custom market data - if not provided, uses default markets */
  markets?: MarketTime[];
  /** Callback when a clock is clicked */
  onClockClick?: (market: MarketTime) => void;
}

/**
 * GlobalMarketClocksModule - A standalone, reusable component for displaying global market clocks
 * 
 * Features:
 * - Completely self-contained with no external dependencies beyond React and Lucide icons
 * - Real-time clock updates every second
 * - Market session awareness (open/closed/after-hours)
 * - Beautiful analog clock SVG animations
 * - Configurable display options
 * - Responsive grid layout
 * - Hover effects with white rimlight
 * - Can be dropped into any React application
 */
export function GlobalMarketClocksModule({
  showHeader = true,
  title = 'Global Trading Sessions',
  subtitle,
  maxClocks = 6,
  showAnalogClocks = true,
  showLegend = true,
  compact = false,
  className = '',
  markets,
  onClockClick
}: GlobalMarketClocksModuleProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Default market data - completely self-contained
  const defaultMarkets: MarketTime[] = [
    {
      city: 'New York',
      timezone: 'America/New_York',
      marketOpen: '09:30',
      marketClose: '16:00',
      afterHoursOpen: '16:00',
      afterHoursClose: '20:00',
      flag: '🇺🇸',
      primaryColorHex: '#F97316',
      exchange: 'NYSE/NASDAQ'
    },
    {
      city: 'London',
      timezone: 'Europe/London',
      marketOpen: '08:00',
      marketClose: '16:30',
      flag: '🇬🇧',
      primaryColorHex: '#EA580C',
      exchange: 'LSE'
    },
    {
      city: 'Tokyo',
      timezone: 'Asia/Tokyo',
      marketOpen: '09:00',
      marketClose: '15:00',
      flag: '🇯🇵',
      primaryColorHex: '#DC2626',
      exchange: 'TSE'
    },
    {
      city: 'Hong Kong',
      timezone: 'Asia/Hong_Kong',
      marketOpen: '09:30',
      marketClose: '16:00',
      flag: '🇭🇰',
      primaryColorHex: '#FACC15',
      exchange: 'HKEX'
    },
    {
      city: 'Sydney',
      timezone: 'Australia/Sydney',
      marketOpen: '10:00',
      marketClose: '16:00',
      flag: '🇦🇺',
      primaryColorHex: '#FB923C',
      exchange: 'ASX'
    },
    {
      city: 'Frankfurt',
      timezone: 'Europe/Berlin',
      marketOpen: '09:00',
      marketClose: '17:30',
      flag: '🇩🇪',
      primaryColorHex: '#8B5CF6',
      exchange: 'XETRA'
    }
  ];

  const marketsData = (markets || defaultMarkets).slice(0, maxClocks);

  const getTimeInTimezone = (timezone: string): string => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).format(currentTime);
  };

  const isMarketOpen = (timezone: string, open: string, close: string): boolean => {
    const marketTime = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(currentTime);

    const [currentHour, currentMinute] = marketTime.split(':').map(Number);
    const [openHour, openMinute] = open.split(':').map(Number);
    const [closeHour, closeMinute] = close.split(':').map(Number);

    const currentTotalMinutes = currentHour * 60 + currentMinute;
    const openTotalMinutes = openHour * 60 + openMinute;
    const closeTotalMinutes = closeHour * 60 + closeMinute;

    return currentTotalMinutes >= openTotalMinutes && currentTotalMinutes <= closeTotalMinutes;
  };

  const isAfterHours = (timezone: string, afterOpen?: string, afterClose?: string): boolean => {
    if (!afterOpen || !afterClose) return false;
    
    const marketTime = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(currentTime);

    const [currentHour, currentMinute] = marketTime.split(':').map(Number);
    const [afterOpenHour, afterOpenMinute] = afterOpen.split(':').map(Number);
    const [afterCloseHour, afterCloseMinute] = afterClose.split(':').map(Number);

    const currentTotalMinutes = currentHour * 60 + currentMinute;
    const afterOpenTotalMinutes = afterOpenHour * 60 + afterOpenMinute;
    const afterCloseTotalMinutes = afterCloseHour * 60 + afterCloseMinute;

    return currentTotalMinutes >= afterOpenTotalMinutes && currentTotalMinutes <= afterCloseTotalMinutes;
  };

  const getAnalogClockSVG = (time: string, colorHex: string, isOpen: boolean, isAfterHours: boolean) => {
    const [hours, minutes, seconds] = time.split(':').map(Number);
    
    // Convert to 12-hour format for analog display
    const hour12 = hours % 12;
    
    // Calculate angles
    const secondAngle = (seconds * 6) - 90; // 6 degrees per second
    const minuteAngle = (minutes * 6 + seconds * 0.1) - 90; // 6 degrees per minute
    const hourAngle = (hour12 * 30 + minutes * 0.5) - 90; // 30 degrees per hour
    
    const size = 80;
    const center = size / 2;
    const clockRadius = 32;
    
    return (
      <svg width={size} height={size} className="transform transition-transform group-hover:scale-110">
        {/* Clock face */}
        <circle
          cx={center}
          cy={center}
          r={clockRadius}
          fill="rgba(15, 23, 42, 0.9)"
          stroke={isOpen ? "#22C55E" : isAfterHours ? "#F59E0B" : "#EF4444"}
          strokeWidth="3"
          className="transition-colors"
        />
        
        {/* Hour markers */}
        {[...Array(12)].map((_, i) => {
          const angle = (i * 30) - 90;
          const x1 = center + (clockRadius - 6) * Math.cos(angle * Math.PI / 180);
          const y1 = center + (clockRadius - 6) * Math.sin(angle * Math.PI / 180);
          const x2 = center + (clockRadius - 2) * Math.cos(angle * Math.PI / 180);
          const y2 = center + (clockRadius - 2) * Math.sin(angle * Math.PI / 180);
          
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="white"
              strokeWidth={i % 3 === 0 ? '2' : '1'}
              className="transition-colors"
            />
          );
        })}
        
        {/* Hour hand */}
        <line
          x1={center}
          y1={center}
          x2={center + 18 * Math.cos(hourAngle * Math.PI / 180)}
          y2={center + 18 * Math.sin(hourAngle * Math.PI / 180)}
          stroke="white"
          strokeWidth="4"
          strokeLinecap="round"
          className="transition-colors"
        />
        
        {/* Minute hand */}
        <line
          x1={center}
          y1={center}
          x2={center + 26 * Math.cos(minuteAngle * Math.PI / 180)}
          y2={center + 26 * Math.sin(minuteAngle * Math.PI / 180)}
          stroke="white"
          strokeWidth="3"
          strokeLinecap="round"
          className="transition-colors"
        />
        
        {/* Second hand */}
        <line
          x1={center}
          y1={center}
          x2={center + 28 * Math.cos(secondAngle * Math.PI / 180)}
          y2={center + 28 * Math.sin(secondAngle * Math.PI / 180)}
          stroke="#EF4444"
          strokeWidth="1"
          strokeLinecap="round"
        />
        
        {/* Center dot */}
        <circle
          cx={center}
          cy={center}
          r="3"
          fill="white"
          className="transition-colors"
        />
        
        {/* Market status indicator */}
        <circle
          cx={center + 22}
          cy={center - 22}
          r="4"
          fill={isOpen ? '#22C55E' : isAfterHours ? '#F59E0B' : '#EF4444'}
          className="transition-colors"
        >
          <animate 
            attributeName="opacity" 
            values={isOpen ? "1;0.3;1" : "1"} 
            dur={isOpen ? "2s" : "0s"} 
            repeatCount="indefinite" 
          />
        </circle>
      </svg>
    );
  };

  return (
    <div className={`bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl border border-indigo-500 hover:shadow-[0_0_25px_rgba(99,102,241,0.8)] hover:border-indigo-400 hover:border-2 transition-all w-full ${className}`}>
      {showHeader && (
        <div className="flex items-center space-x-3 mb-6">
          <Globe className="h-6 w-6 text-indigo-400" />
          <div className="flex-1">
            <h2 className="text-xl font-bold text-white">{title}</h2>
            {subtitle && <p className="text-sm text-gray-400">{subtitle}</p>}
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse" />
            <span className="text-xs text-indigo-300">LIVE</span>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
        {marketsData.map((market) => {
          const time = getTimeInTimezone(market.timezone);
          const isOpen = isMarketOpen(market.timezone, market.marketOpen, market.marketClose);
          const afterHours = isAfterHours(market.timezone, market.afterHoursOpen, market.afterHoursClose);
          
          return (
            <div 
              key={market.city} 
              onClick={() => onClockClick && onClockClick(market)}
              className="group text-center hover:scale-105 transition-all duration-300 cursor-pointer bg-slate-700/50 p-4 rounded-lg border-2 border-slate-600/50 hover:border-white hover:shadow-[0_0_25px_rgba(255,255,255,0.8)]"
            >
              {showAnalogClocks && (
                <div className="relative mb-4">
                  {getAnalogClockSVG(time, market.primaryColorHex, isOpen, afterHours)}
                </div>
              )}
              
              <div className="space-y-2">
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-2xl">{market.flag}</span>
                  <div className="text-center">
                    <p className="font-bold text-white text-sm">{market.city}</p>
                    {!compact && <p className="text-xs text-gray-400">{market.exchange}</p>}
                  </div>
                </div>
                
                <div className="text-center">
                  <p className="text-white font-mono text-lg">{time}</p>
                  {!compact && <p className="text-xs text-gray-400">{market.timezone.split('/')[1]}</p>}
                </div>
                
                <div className="space-y-1">
                  <div className={`text-xs px-2 py-1 rounded-full border ${
                    isOpen 
                      ? 'bg-green-900/30 border-green-700/50 text-green-200 shadow-[0_0_10px_rgba(34,197,94,0.8)]' 
                      : afterHours
                        ? 'bg-yellow-900/30 border-yellow-700/50 text-yellow-200'
                        : 'bg-red-900/30 border-red-700/50 text-red-200 shadow-[0_0_10px_rgba(239,68,68,0.8)]'
                  }`}>
                    {isOpen ? 'OPEN' : afterHours ? 'AFTER HOURS' : 'CLOSED'}
                  </div>
                  
                  {!compact && (
                    <div className="text-xs text-gray-400">
                      {isOpen 
                        ? `Closes ${market.marketClose}`
                        : afterHours 
                          ? `AH until ${market.afterHoursClose}`
                          : `Opens ${market.marketOpen}`}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Market Hours Legend */}
      {showLegend && (
        <div className="mt-6 pt-4 border-t border-slate-600/30">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.8)]"></div>
              <span className="text-gray-300">Market Open</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span className="text-gray-300">After Hours Trading (NY only)</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)]"></div>
              <span className="text-gray-300">Market Closed</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default GlobalMarketClocksModule;