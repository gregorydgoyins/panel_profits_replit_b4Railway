import React, { useState } from 'react';
import { Calendar, Building2, TrendingUp, TrendingDown, Info, Star, Clock } from 'lucide-react';

interface QuarterlyReport {
  id: string;
  company: string;
  symbol: string;
  type: 'publisher' | 'creator' | 'fund' | 'platform';
  reportDate: Date;
  quarter: string;
  year: number;
  expectedImpact: 'high' | 'medium' | 'low';
  expectedDirection: 'positive' | 'negative' | 'neutral';
  previousEarnings?: {
    eps: number;
    revenue: number;
    guidance: 'beat' | 'met' | 'missed';
  };
  analystConsensus?: {
    epsEstimate: number;
    revenueEstimate: number;
  };
}

interface QuarterlyReportsModuleProps {
  /** Maximum number of reports to display */
  maxReports?: number;
  /** Show type and risk filters */
  showFilters?: boolean;
  /** Compact mode for smaller displays */
  compact?: boolean;
  /** Custom CSS classes */
  className?: string;
  /** Custom title */
  title?: string;
  /** Custom subtitle */
  subtitle?: string;
  /** Reports data - if not provided, uses mock data */
  reports?: QuarterlyReport[];
  /** Callback when a report is clicked */
  onReportClick?: (report: QuarterlyReport) => void;
  /** Custom icons for different types */
  customIcons?: {
    publisher?: React.ComponentType<{ className?: string }>;
    creator?: React.ComponentType<{ className?: string }>;
    fund?: React.ComponentType<{ className?: string }>;
    platform?: React.ComponentType<{ className?: string }>;
  };
}

/**
 * QuarterlyReportsModule - A standalone, reusable component for displaying upcoming quarterly earnings reports
 * 
 * Features:
 * - Completely self-contained with no external dependencies beyond React and Lucide icons
 * - Configurable filtering and display options
 * - Visual indicators for earnings performance (beat/met/missed expectations)
 * - Responsive grid layout
 * - Hover effects with earnings-based rimlight colors
 * - Can be dropped into any React application
 */
export function QuarterlyReportsModule({
  maxReports = 8,
  showFilters = true,
  compact = false,
  className = '',
  title = 'Upcoming Quarterly Reports',
  subtitle = 'Market Calendar',
  reports,
  onReportClick,
  customIcons
}: QuarterlyReportsModuleProps) {
  const [selectedType, setSelectedType] = useState('all');

  // Default mock data - completely self-contained
  const defaultReports: QuarterlyReport[] = [
    {
      id: 'QR1',
      company: 'Marvel Entertainment',
      symbol: 'MRVL',
      type: 'publisher',
      reportDate: new Date('2025-01-28'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'high',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 2.45,
        revenue: 890000000,
        guidance: 'beat'
      },
      analystConsensus: {
        epsEstimate: 2.65,
        revenueEstimate: 920000000
      }
    },
    {
      id: 'QR2',
      company: 'DC Comics',
      symbol: 'DCCP',
      type: 'publisher',
      reportDate: new Date('2025-02-05'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'high',
      expectedDirection: 'neutral',
      previousEarnings: {
        eps: 1.85,
        revenue: 650000000,
        guidance: 'met'
      },
      analystConsensus: {
        epsEstimate: 1.95,
        revenueEstimate: 680000000
      }
    },
    {
      id: 'QR3',
      company: 'Image Comics',
      symbol: 'IMGC',
      type: 'publisher',
      reportDate: new Date('2025-02-12'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'medium',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 0.95,
        revenue: 125000000,
        guidance: 'beat'
      },
      analystConsensus: {
        epsEstimate: 1.05,
        revenueEstimate: 135000000
      }
    },
    {
      id: 'QR4',
      company: 'Comic Capital Management',
      symbol: 'CCMF',
      type: 'fund',
      reportDate: new Date('2025-02-15'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'medium',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 3.25,
        revenue: 285000000,
        guidance: 'beat'
      },
      analystConsensus: {
        epsEstimate: 3.45,
        revenueEstimate: 295000000
      }
    },
    {
      id: 'QR5',
      company: 'Todd McFarlane Productions',
      symbol: 'TMFP',
      type: 'creator',
      reportDate: new Date('2025-02-20'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'medium',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 1.65,
        revenue: 45000000,
        guidance: 'missed'
      },
      analystConsensus: {
        epsEstimate: 1.75,
        revenueEstimate: 48000000
      }
    },
    {
      id: 'QR6',
      company: 'Panel Profits Platform',
      symbol: 'PPFP',
      type: 'platform',
      reportDate: new Date('2025-02-28'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'high',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 0.85,
        revenue: 125000000,
        guidance: 'beat'
      },
      analystConsensus: {
        epsEstimate: 1.25,
        revenueEstimate: 165000000
      }
    },
    {
      id: 'QR7',
      company: 'Dark Horse Comics',
      symbol: 'DKHS',
      type: 'publisher',
      reportDate: new Date('2025-03-05'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'medium',
      expectedDirection: 'neutral',
      previousEarnings: {
        eps: 0.75,
        revenue: 85000000,
        guidance: 'met'
      },
      analystConsensus: {
        epsEstimate: 0.80,
        revenueEstimate: 88000000
      }
    },
    {
      id: 'QR8',
      company: 'Jim Lee Studios',
      symbol: 'JLES',
      type: 'creator',
      reportDate: new Date('2025-03-12'),
      quarter: 'Q4',
      year: 2024,
      expectedImpact: 'medium',
      expectedDirection: 'positive',
      previousEarnings: {
        eps: 2.15,
        revenue: 65000000,
        guidance: 'met'
      },
      analystConsensus: {
        epsEstimate: 2.35,
        revenueEstimate: 70000000
      }
    }
  ];

  const reportsData = reports || defaultReports;

  // Filter reports based on selected criteria
  const filteredReports = reportsData.filter(report => {
    const matchesType = selectedType === 'all' || report.type === selectedType;
    return matchesType;
  }).slice(0, maxReports);

  const getTypeIcon = (type: string) => {
    if (customIcons) {
      switch (type) {
        case 'publisher': return customIcons.publisher ? <customIcons.publisher className="h-5 w-5 text-blue-400" /> : <Building2 className="h-5 w-5 text-blue-400" />;
        case 'creator': return customIcons.creator ? <customIcons.creator className="h-5 w-5 text-yellow-400" /> : <Star className="h-5 w-5 text-yellow-400" />;
        case 'fund': return customIcons.fund ? <customIcons.fund className="h-5 w-5 text-green-400" /> : <TrendingUp className="h-5 w-5 text-green-400" />;
        case 'platform': return customIcons.platform ? <customIcons.platform className="h-5 w-5 text-purple-400" /> : <Calendar className="h-5 w-5 text-purple-400" />;
        default: return <Building2 className="h-5 w-5 text-gray-400" />;
      }
    }
    
    switch (type) {
      case 'publisher': return <Building2 className="h-5 w-5 text-blue-400" />;
      case 'creator': return <Star className="h-5 w-5 text-yellow-400" />;
      case 'fund': return <TrendingUp className="h-5 w-5 text-green-400" />;
      case 'platform': return <Calendar className="h-5 w-5 text-purple-400" />;
      default: return <Building2 className="h-5 w-5 text-gray-400" />;
    }
  };

  const getExpectedDirectionIcon = (direction: string) => {
    switch (direction) {
      case 'positive': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'negative': return <TrendingDown className="h-4 w-4 text-red-400" />;
      default: return <Info className="h-4 w-4 text-yellow-400" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-900/30 border-red-700/30 text-red-200';
      case 'medium': return 'bg-yellow-900/30 border-yellow-700/30 text-yellow-200';
      case 'low': return 'bg-green-900/30 border-green-700/30 text-green-200';
      default: return 'bg-gray-900/30 border-gray-700/30 text-gray-200';
    }
  };

  const getEarningsPerformanceRimlight = (guidance: 'beat' | 'met' | 'missed') => {
    switch (guidance) {
      case 'beat': return 'hover:shadow-[0_0_25px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2';
      case 'met': return 'hover:shadow-[0_0_25px_rgba(234,179,8,0.8)] hover:border-yellow-400 hover:border-2';
      case 'missed': return 'hover:shadow-[0_0_25px_rgba(239,68,68,0.8)] hover:border-red-400 hover:border-2';
      default: return 'hover:shadow-[0_0_25px_rgba(255,255,255,0.8)] hover:border-white hover:border-2';
    }
  };

  const formatReportDate = (date: Date) => {
    const now = new Date();
    const diffTime = date.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays <= 7) return `${diffDays} days`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const handleReportClick = (report: QuarterlyReport) => {
    if (onReportClick) {
      onReportClick(report);
    }
  };

  return (
    <div className={`bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl border border-green-500 hover:shadow-[0_0_25px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2 transition-all w-full ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Calendar className="h-6 w-6 text-green-400" />
          <div>
            <h2 className="text-xl font-bold text-white">{title}</h2>
            {subtitle && <p className="text-sm text-gray-400">{subtitle}</p>}
          </div>
        </div>
        
        {showFilters && (
          <div className="flex items-center space-x-4">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-slate-700/50 text-white text-sm border-slate-600/50 rounded-lg px-3 py-2"
            >
              <option value="all">All Types</option>
              <option value="publisher">Publishers</option>
              <option value="creator">Creators</option>
              <option value="fund">Funds</option>
              <option value="platform">Platforms</option>
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredReports.map((report) => (
          <div 
            key={report.id}
            onClick={() => handleReportClick(report)}
            className={`p-4 rounded-lg border transition-all cursor-pointer border border-transparent ${getImpactColor(report.expectedImpact)} ${
              report.previousEarnings ? getEarningsPerformanceRimlight(report.previousEarnings.guidance) : 'hover:shadow-[0_0_25px_rgba(255,255,255,0.8)] hover:border-white hover:border-2'
            }`}
          >
            <div className="flex items-start space-x-3 mb-3">
              <div className="p-2 rounded-full bg-slate-800/50">
                {getTypeIcon(report.type)}
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-white text-sm">{report.company}</h3>
                <p className="text-xs text-gray-400">{report.symbol} • {report.quarter} {report.year}</p>
              </div>
              <div className="flex items-center space-x-1">
                {getExpectedDirectionIcon(report.expectedDirection)}
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <Clock className="h-3 w-3 text-gray-400" />
                  <span className="text-xs text-gray-400">{formatReportDate(report.reportDate)}</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getImpactColor(report.expectedImpact)}`}>
                  {report.expectedImpact.toUpperCase()}
                </span>
              </div>
              
              {!compact && report.analystConsensus && (
                <div className="bg-slate-700/30 p-2 rounded border border-slate-600/30">
                  <p className="text-xs text-gray-400 mb-1">Analyst Consensus:</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-gray-400">EPS:</span>
                      <span className="text-white ml-1">${report.analystConsensus.epsEstimate}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Rev:</span>
                      <span className="text-white ml-1">
                        ${(report.analystConsensus.revenueEstimate / 1000000).toFixed(0)}M
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              {!compact && report.previousEarnings && (
                <div className="text-xs text-gray-400">
                  <span>Last Q: </span>
                  <span className={`${
                    report.previousEarnings.guidance === 'beat' ? 'text-green-400' :
                    report.previousEarnings.guidance === 'missed' ? 'text-red-400' :
                    'text-yellow-400'
                  }`}>
                    {report.previousEarnings.guidance.toUpperCase()}
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-slate-600/30">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-400">
            <span className="text-green-400 font-medium">
              {filteredReports.filter(r => r.expectedDirection === 'positive').length}
            </span>
            <span> positive outlooks, </span>
            <span className="text-red-400 font-medium">
              {filteredReports.filter(r => r.expectedDirection === 'negative').length}
            </span>
            <span> negative expectations this quarter</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default QuarterlyReportsModule;