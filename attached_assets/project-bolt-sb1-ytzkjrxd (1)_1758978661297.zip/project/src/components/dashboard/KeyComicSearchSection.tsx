import React, { useState } from 'react';
import { BookOpen, Search, TrendingUp, TrendingDown, Star, Check } from 'lucide-react';
import { Link } from 'react-router-dom';

// Self-contained interfaces - no external dependencies
interface ComicAsset {
  id: string;
  symbol: string;
  title: string;
  name: string;
  type: 'comic' | 'character' | 'creator' | 'publisher';
  currentPrice: number;
  price: number;
  change: number;
  percentChange: number;
  age: 'golden' | 'silver' | 'bronze' | 'modern';
  imageUrl: string;
  description: string;
  recommendation: 'Strong Buy' | 'Buy' | 'Hold' | 'Sell';
  publisher: 'marvel' | 'dc' | 'image' | 'other';
  keywords: string[];
}

// Hardcoded mock data - completely self-contained
const MOCK_COMIC_ASSETS: ComicAsset[] = [
  {
    id: '1',
    symbol: 'ACM1',
    title: 'Action Comics #1',
    name: 'Action Comics #1',
    type: 'comic',
    currentPrice: 3200000,
    price: 3200000,
    change: 130000,
    percentChange: 4.06,
    age: 'golden',
    imageUrl: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'The iconic debut of Superman, marking the beginning of the Golden Age of comics. A cornerstone of comic history.',
    publisher: 'dc',
    recommendation: 'Strong Buy',
    keywords: ['superman', 'first appearance', 'golden age', 'dc comics']
  },
  {
    id: '2',
    symbol: 'DTM27',
    title: 'Detective Comics #27',
    name: 'Detective Comics #27',
    type: 'comic',
    currentPrice: 2800000,
    price: 2800000,
    change: 87640,
    percentChange: 3.13,
    age: 'golden',
    imageUrl: 'https://images.pexels.com/photos/114741/pexels-photo-114741.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Batman\'s first appearance, a monumental issue that launched one of the most enduring characters in pop culture.',
    publisher: 'dc',
    recommendation: 'Strong Buy',
    keywords: ['batman', 'first appearance', 'golden age', 'dc comics']
  },
  {
    id: '3',
    symbol: 'AF15',
    title: 'Amazing Fantasy #15',
    name: 'Amazing Fantasy #15',
    type: 'comic',
    currentPrice: 1800000,
    price: 1800000,
    change: 100260,
    percentChange: 5.57,
    age: 'silver',
    imageUrl: 'https://images.pexels.com/photos/163186/spider-web-with-water-beads-network-dewdrop-163186.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'The legendary first appearance of Spider-Man, a character that redefined the superhero genre.',
    publisher: 'marvel',
    recommendation: 'Strong Buy',
    keywords: ['spider-man', 'first appearance', 'silver age', 'marvel']
  },
  {
    id: '4',
    symbol: 'ASM300',
    title: 'Amazing Spider-Man #300',
    name: 'Amazing Spider-Man #300',
    type: 'comic',
    currentPrice: 2500,
    price: 2500,
    change: 125,
    percentChange: 5.26,
    age: 'modern',
    imageUrl: 'https://images.pexels.com/photos/3861458/pexels-photo-3861458.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'Features the first full appearance of Venom, a fan-favorite villain and anti-hero.',
    publisher: 'marvel',
    recommendation: 'Buy',
    keywords: ['venom', 'first appearance', 'modern age', 'marvel']
  },
  {
    id: '5',
    symbol: 'FF1',
    title: 'Fantastic Four #1',
    name: 'Fantastic Four #1',
    type: 'comic',
    currentPrice: 450000,
    price: 450000,
    change: 18000,
    percentChange: 4.17,
    age: 'silver',
    imageUrl: 'https://images.pexels.com/photos/159591/construction-site-build-construction-work-159591.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'The debut of Marvel\'s first family, the Fantastic Four, ushering in a new era of superhero storytelling.',
    publisher: 'marvel',
    recommendation: 'Buy',
    keywords: ['fantastic four', 'first appearance', 'silver age', 'marvel']
  },
  {
    id: '6',
    symbol: 'XM1',
    title: 'X-Men #1',
    name: 'X-Men #1',
    type: 'comic',
    currentPrice: 185000,
    price: 185000,
    change: 7400,
    percentChange: 4.00,
    age: 'silver',
    imageUrl: 'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'The inaugural issue of the X-Men, introducing a team of mutant heroes fighting for a world that fears them.',
    publisher: 'marvel',
    recommendation: 'Buy',
    keywords: ['x-men', 'first appearance', 'silver age', 'marvel']
  },
  {
    id: '7',
    symbol: 'SPDR',
    title: 'Spider-Man Character Stock',
    name: 'Spider-Man',
    type: 'character',
    currentPrice: 7200,
    price: 7200,
    change: 381.60,
    percentChange: 5.30,
    age: 'silver',
    imageUrl: 'https://images.pexels.com/photos/163186/spider-web-with-water-beads-network-dewdrop-163186.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'A stock representing the overall market value and popularity of the Spider-Man character.',
    publisher: 'marvel',
    recommendation: 'Strong Buy',
    keywords: ['spider-man', 'character', 'hero', 'marvel']
  },
  {
    id: '8',
    symbol: 'BATM',
    title: 'Batman Character Stock',
    name: 'Batman',
    type: 'character',
    currentPrice: 6800,
    price: 6800,
    change: 360.40,
    percentChange: 5.30,
    age: 'golden',
    imageUrl: 'https://images.pexels.com/photos/114741/pexels-photo-114741.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'A stock representing the overall market value and enduring popularity of the Batman character.',
    publisher: 'dc',
    recommendation: 'Strong Buy',
    keywords: ['batman', 'character', 'hero', 'dc comics']
  },
  {
    id: '9',
    symbol: 'TMFS',
    title: 'Todd McFarlane Creator Stock',
    name: 'Todd McFarlane',
    type: 'creator',
    currentPrice: 2500,
    price: 2500,
    change: 130,
    percentChange: 5.20,
    age: 'modern',
    imageUrl: 'https://images.pexels.com/photos/3861458/pexels-photo-3861458.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'A stock representing the market influence and creative output of legendary creator Todd McFarlane.',
    publisher: 'image',
    recommendation: 'Buy',
    keywords: ['todd mcfarlane', 'creator', 'spawn', 'image comics']
  },
  {
    id: '10',
    symbol: 'WW1',
    title: 'Wonder Woman #1',
    name: 'Wonder Woman #1',
    type: 'comic',
    currentPrice: 85000,
    price: 85000,
    change: 3332,
    percentChange: 3.92,
    age: 'golden',
    imageUrl: 'https://images.pexels.com/photos/159581/dictionary-reference-book-learning-study-159581.jpeg?auto=compress&cs=tinysrgb&w=400',
    description: 'The first solo title for Wonder Woman, solidifying her status as a major superheroine.',
    publisher: 'dc',
    recommendation: 'Buy',
    keywords: ['wonder woman', 'first appearance', 'golden age', 'dc comics']
  }
];

// Quick access comics for default display - hardcoded
const QUICK_ACCESS_COMICS = [
  { symbol: 'ACM1', title: 'Action Comics #1', price: 3200000, change: 4.06, imageUrl: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400', description: 'First appearance of Superman.', recommendation: 'Strong Buy' },
  { symbol: 'DTM27', title: 'Detective Comics #27', price: 2800000, change: 3.13, imageUrl: 'https://images.pexels.com/photos/114741/pexels-photo-114741.jpeg?auto=compress&cs=tinysrgb&w=400', description: 'First appearance of Batman.', recommendation: 'Strong Buy' },
  { symbol: 'AF15', title: 'Amazing Fantasy #15', price: 1800000, change: 5.57, imageUrl: 'https://images.pexels.com/photos/163186/spider-web-with-water-beads-network-dewdrop-163186.jpeg?auto=compress&cs=tinysrgb&w=400', description: 'First appearance of Spider-Man.', recommendation: 'Strong Buy' },
  { symbol: 'ASM300', title: 'Amazing Spider-Man #300', price: 2500, change: 5.26, imageUrl: 'https://images.pexels.com/photos/3861458/pexels-photo-3861458.jpeg?auto=compress&cs=tinysrgb&w=400', description: 'First full appearance of Venom.', recommendation: 'Buy' }
];

// Completely self-contained and portable component
export function KeyComicSearchSection() {
  // Internal state - no external dependencies
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAge, setSelectedAge] = useState('all');
  const [selectedPublisher, setSelectedPublisher] = useState('all');
  const [watchlist, setWatchlist] = useState<Set<string>>(new Set());
  const [addingToWatchlist, setAddingToWatchlist] = useState<string | null>(null);

  const getRatingColor = (rating: string) => {
    switch (rating) {
      case 'Strong Buy':
        return 'bg-green-900/50 text-green-200 border-green-700/50';
      case 'Buy':
        return 'bg-emerald-900/50 text-emerald-200 border-emerald-700/50';
      case 'Hold':
        return 'bg-yellow-900/50 text-yellow-200 border-yellow-700/50';
      case 'Sell':
        return 'bg-red-900/50 text-red-200 border-red-700/50';
      default:
        return 'bg-gray-900/50 text-gray-200 border-gray-700/50';
    }
  };

  // Internal search function - completely self-contained
  const performSearch = (query: string): ComicAsset[] => {
    if (!query.trim()) return [];
    
    const lowerQuery = query.toLowerCase();
    return MOCK_COMIC_ASSETS.filter(asset => {
      const matchesQuery = 
        asset.title.toLowerCase().includes(lowerQuery) ||
        asset.symbol.toLowerCase().includes(lowerQuery) ||
        asset.keywords.some(keyword => keyword.toLowerCase().includes(lowerQuery));

      const matchesAge = selectedAge === 'all' || asset.age === selectedAge;
      const matchesPublisher = selectedPublisher === 'all' || asset.publisher === selectedPublisher;
      
      return matchesQuery && matchesAge && matchesPublisher;
    });
  };

  // Internal watchlist management - no external dependencies
  const handleAddToWatchlist = async (symbol: string) => {
    setAddingToWatchlist(symbol);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setWatchlist(prev => new Set([...prev, symbol]));
    setAddingToWatchlist(null);
    
    // Auto-remove success state after 3 seconds
    setTimeout(() => {
      setWatchlist(prev => {
        const newSet = new Set(prev);
        newSet.delete(symbol);
        return newSet;
      });
    }, 3000);
  };

  const searchResults = performSearch(searchQuery);

  return (
    <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl border border-yellow-500 hover:shadow-[0_0_25px_rgba(234,179,8,0.8)] hover:border-yellow-400 hover:border-2 transition-all w-full">
      <div className="flex items-center space-x-3 mb-6">
        <BookOpen className="h-6 w-6 text-indigo-400" />
        <h2 className="text-2xl font-bold text-white">Key Comic Pricing Search</h2>
        <div className="ml-auto">
          <span className="px-2 py-1 bg-indigo-900/50 text-indigo-200 rounded-full text-xs border border-indigo-700/50">
            Panel Profits Pricing
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Search Controls Foundation */}
        <div className="bg-slate-700/50 p-4 rounded-lg border-2 border-blue-500 hover:border-blue-400 hover:shadow-[0_0_30px_rgba(59,130,246,1.0)] transition-all duration-300 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by title, symbol, or character..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-3 w-full bg-slate-700/50 border border-slate-600/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 hover:shadow-[0_0_25px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <select 
              value={selectedAge}
              onChange={(e) => setSelectedAge(e.target.value)}
              className="bg-slate-700/50 text-white border-slate-600/50 rounded-lg px-3 py-2 border-2 border-transparent hover:border-purple-400 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)] focus:border-purple-400 focus:shadow-[0_0_25px_rgba(147,51,234,0.8)] transition-all"
            >
              <option value="all">All Ages</option>
              <option value="golden">Golden Age</option>
              <option value="silver">Silver Age</option>
              <option value="bronze">Bronze Age</option>
              <option value="modern">Modern Age</option>
            </select>
            
            <select 
              value={selectedPublisher}
              onChange={(e) => setSelectedPublisher(e.target.value)}
              className="bg-slate-700/50 text-white border-slate-600/50 rounded-lg px-3 py-2 border-2 border-transparent hover:border-purple-400 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)] focus:border-purple-400 focus:shadow-[0_0_25px_rgba(147,51,234,0.8)] transition-all"
            >
              <option value="all">All Publishers</option>
              <option value="marvel">Marvel</option>
              <option value="dc">DC Comics</option>
              <option value="image">Image</option>
            </select>
          </div>
          
          {/* Advanced Search Button Foundation */}
          <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
            <Link
              to="/key-comics"
              className="block w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-lg transition-all text-center hover:shadow-[0_0_25px_rgba(255,215,0,0.8)] hover:border-yellow-400 hover:border-2 border border-transparent"
            >
              Advanced Search
            </Link>
          </div>

          {/* Search Results Foundation */}
          <div className={`bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 min-h-[240px] border-2 border-transparent transition-all ${
            searchQuery ? 'border-purple-400 shadow-[0_0_25px_rgba(147,51,234,0.8)]' : 'hover:border-purple-400 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)]'
          }`}>
            <h4 className="font-medium text-white mb-3">Search Results</h4>
            {searchQuery ? (
              <div className="space-y-3 max-h-52 overflow-y-auto">
                {searchResults.length > 0 ? (
                  searchResults.slice(0, 4).map((comic) => {
                    const linkPath = `/key-comics`; // Assuming a generic key-comics page for now
                    return (
                      <div
                        key={comic.id}
                        className="flex p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 border-2 border-transparent hover:border-purple-400 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)] transition-all duration-300"
                      >
                        <Link to={linkPath} className="flex-1 flex items-start space-x-3">
                          <img src={comic.imageUrl} alt={comic.title} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <p className="text-white font-medium">{comic.title}</p>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getRatingColor(comic.recommendation)}`}>
                                {comic.recommendation}
                              </span>
                            </div>
                            <p className="text-xs text-gray-400 mb-1">{comic.symbol} • {comic.publisher.toUpperCase()}</p>
                            <p className="text-xs text-gray-300 line-clamp-2">{comic.description}</p>
                            <div className="flex items-center justify-between mt-2">
                              <p className="text-white font-medium">CC {comic.currentPrice.toLocaleString()}</p>
                              <div className="flex items-center space-x-1">
                                {comic.change > 0 ? (
                                  <TrendingUp className="h-3 w-3 text-green-400" />
                                ) : (
                                  <TrendingDown className="h-3 w-3 text-red-400" />
                                )}
                                <p className={`text-sm ${comic.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                  {comic.change > 0 ? '+' : ''}{comic.percentChange.toFixed(2)}%
                                </p>
                              </div>
                            </div>
                          </div>
                        </Link>
                        <div className="ml-3 flex-shrink-0">
                        <button
                          onClick={() => handleAddToWatchlist(comic.symbol)}
                          disabled={addingToWatchlist === comic.symbol || watchlist.has(comic.symbol)}
                          className={`p-2 rounded-lg transition-all hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent ${
                            watchlist.has(comic.symbol)
                              ? 'bg-green-600 text-white'
                              : 'bg-slate-700 hover:bg-yellow-600 text-gray-300 hover:text-white'
                          }`}
                          title="Add to Watchlist"
                        >
                          {watchlist.has(comic.symbol) ? (
                            <Check className="h-4 w-4" />
                          ) : (
                            <Star className="h-4 w-4" />
                          )}
                        </button>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-gray-400 text-sm text-center py-4">No results found</p>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-center h-32">
                <p className="text-gray-400 text-sm">Search results will appear here</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Quick Price Lookup Foundation */}
        <div className="bg-slate-700/50 p-4 rounded-lg border-2 border-blue-500 hover:border-blue-400 hover:shadow-[0_0_30px_rgba(59,130,246,1.0)] transition-all duration-300">
          <h3 className="font-medium text-white mb-4">
            {searchQuery ? 'Search Results' : 'Quick Price Lookup'}
          </h3>
          
          <div className="space-y-3 border-2 border-blue-500 hover:border-blue-400 hover:shadow-[0_0_30px_rgba(59,130,246,1.0)] transition-all duration-300 rounded-lg p-3 bg-slate-800/30">
            {QUICK_ACCESS_COMICS.map((comic, index) => (
              <div key={index}
                className="flex p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 border-2 border-transparent hover:border-purple-400 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)] transition-all duration-300">
                <Link to={`/key-comics`} className="flex-1 flex items-start space-x-3">
                  <img src={comic.imageUrl} alt={comic.title} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-white font-medium">{comic.title}</p>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getRatingColor(comic.recommendation)}`}>
                        {comic.recommendation}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mb-1">{comic.symbol} • {comic.description}</p>
                    <div className="flex items-center justify-between mt-2">
                      <p className="text-white font-medium">CC {comic.price.toLocaleString()}</p>
                      <div className="flex items-center space-x-1">
                        {comic.change > 0 ? (
                          <TrendingUp className="h-3 w-3 text-green-400" />
                        ) : (
                          <TrendingDown className="h-3 w-3 text-red-400" />
                        )}
                        <p className={`text-sm ${comic.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {comic.change > 0 ? '+' : ''}{comic.change}%
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
                <div className="ml-3 flex-shrink-0">
                  <button
                    onClick={() => handleAddToWatchlist(comic.symbol)}
                    disabled={addingToWatchlist === comic.symbol || watchlist.has(comic.symbol)}
                    className={`p-2 rounded-lg transition-all hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent ${
                      watchlist.has(comic.symbol)
                        ? 'bg-green-600 text-white'
                        : 'bg-slate-700 hover:bg-yellow-600 text-gray-300 hover:text-white'
                    }`}
                    title="Add to Watchlist"
                  >
                    {watchlist.has(comic.symbol) ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Star className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <Link 
            to="/key-comics"
            className="block w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded-lg transition-all hover:shadow-[0_0_25px_rgba(255,215,0,0.8)] hover:border-yellow-400 hover:border-2 border border-transparent"
          >
            View All Key Comics
          </Link>
        </div>
      </div>
    </div>
  );
}

export default KeyComicSearchSection;