import React, { useState } from 'react';
import { TrendingUp, BarChart2, AlertTriangle, Star, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { QuickTradeModal } from '../trading/QuickTradeModal';

// Type definitions for the widget
interface TopBuyRecommendation {
  symbol: string;
  name: string;
  assetType: string;
  currentPrice: number;
  targetPrice: number;
  description: string;
  marketActivity: string;
}

interface DiversificationRecommendation {
  title: string;
  subtitle: string;
  description: string;
  currentAllocation: number;
  recommendedAllocation: string;
  exploreLink: string;
  exploreText: string;
}

interface RiskAlert {
  title: string;
  subtitle: string;
  description: string;
  currentExposure: number;
  recommendedMax: number;
  severity: 'low' | 'medium' | 'high';
  reviewLink: string;
}

interface SmartRecommendationsWidgetProps {
  topBuy?: TopBuyRecommendation;
  diversification?: DiversificationRecommendation;
  riskAlert?: RiskAlert;
  className?: string;
  showCards?: {
    topBuy?: boolean;
    diversification?: boolean;
    riskAlert?: boolean;
  };
}

// Default data if none provided
const defaultTopBuy: TopBuyRecommendation = {
  symbol: 'ASM300',
  name: 'Amazing Spider-Man #300',
  assetType: 'Character',
  currentPrice: 25.00,
  targetPrice: 32.00,
  description: 'Strong buy signal based on upcoming Venom movie announcements and increasing collector interest.',
  marketActivity: 'High volume expected'
};

const defaultDiversification: DiversificationRecommendation = {
  title: 'Golden Age Comics',
  subtitle: 'Portfolio Allocation',
  description: 'Your portfolio is underweight in Golden Age comics. Consider adding exposure to this stable, historically significant segment.',
  currentAllocation: 5,
  recommendedAllocation: '15-20%',
  exploreLink: '/funds/themed',
  exploreText: 'Explore Golden Age Funds'
};

const defaultRiskAlert: RiskAlert = {
  title: 'Options Exposure',
  subtitle: 'Portfolio Risk',
  description: 'Your options positions represent 25% of your portfolio, exceeding the recommended maximum of 15% for your risk profile.',
  currentExposure: 25,
  recommendedMax: 15,
  severity: 'medium',
  reviewLink: '/portfolio'
};

export function SmartRecommendationsWidget({
  topBuy = defaultTopBuy,
  diversification = defaultDiversification,
  riskAlert = defaultRiskAlert,
  className = '',
  showCards = { topBuy: true, diversification: true, riskAlert: true }
}: SmartRecommendationsWidgetProps) {
  // Modal states
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);

  // Get severity colors for risk alert
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-orange-600';
      case 'low': return 'text-yellow-600';
      default: return 'text-orange-600';
    }
  };

  const getSeverityTextColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-orange-400';
      case 'low': return 'text-yellow-400';
      default: return 'text-orange-400';
    }
  };

  // Calculate number of visible cards
  const visibleCards = Object.values(showCards).filter(Boolean).length;
  const getGridCols = () => {
    if (visibleCards === 1) return 'grid-cols-1';
    if (visibleCards === 2) return 'grid-cols-1 md:grid-cols-2';
    return 'grid-cols-1 md:grid-cols-3';
  };

  return (
    <>
      {/* Smart Recommendations Widget Container */}
      <div className={`bg-slate-800 p-4 rounded-xl hover:shadow-[0_0_25px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent transition-all ${className}`}>
        <div className={`grid ${getGridCols()} gap-4`}>
          {/* Top Buy Recommendation Card */}
          {showCards.topBuy && (
            <div className="bg-slate-700 p-2 rounded-xl">
              <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-5 shadow-xl hover:shadow-[0_0_25px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2 border border-green-500 transition-all hover:-translate-y-1 flex flex-col h-[400px]">
                <div className="flex items-center space-x-2 mb-3">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                  <h3 className="font-semibold text-white">Top Buy Recommendation</h3>
                </div>
                
                <div className="flex items-center space-x-3 mb-4">
                  <div className="bg-slate-800 rounded-full p-2">
                    <Star className="h-6 w-6 text-yellow-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{topBuy.name}</h4>
                    <p className="text-sm text-gray-400">{topBuy.symbol} • {topBuy.assetType}</p>
                  </div>
                </div>
                
                <div className="flex-grow">
                  <p className="text-sm text-gray-300 mb-4">
                    {topBuy.description}
                  </p>
                
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Current Price:</span>
                      <span className="text-white">CC {topBuy.currentPrice.toFixed(2)} per share</span>
                    </div>
                
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Target Price:</span>
                      <span className="text-white">CC {topBuy.targetPrice.toFixed(2)} per share</span>
                    </div>
                
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Market Activity:</span>
                      <span className="text-white">{topBuy.marketActivity}</span>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => setIsTradeModalOpen(true)}
                  className="block w-full bg-green-600 hover:bg-green-700 text-white text-center py-2 rounded-lg transition-all hover:shadow-[0_0_25px_rgba(34,197,94,1.0)] hover:border-green-400 hover:border-2 border border-transparent focus-visible:shadow-[0_0_25px_rgba(34,197,94,1.0)] focus-visible:border-green-400 focus-visible:border-2"
                >
                  Trade Now
                </button>
              </div>
            </div>
          )}

          {/* Diversification Tip Card */}
          {showCards.diversification && (
            <div className="bg-slate-700 p-2 rounded-xl">
              <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-5 shadow-xl hover:shadow-[0_0_25px_rgba(234,179,8,0.8)] hover:border-yellow-400 hover:border-2 border border-yellow-500 transition-all hover:-translate-y-1 flex flex-col h-[400px]">
                <div className="flex items-center space-x-2 mb-3">
                  <BarChart2 className="h-5 w-5 text-yellow-400" />
                  <h3 className="font-semibold text-white">Diversification Tip</h3>
                </div>
                
                <div className="flex items-center space-x-3 mb-3">
                  <div className="bg-slate-700 rounded-full p-2">
                    <BarChart2 className="h-6 w-6 text-yellow-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{diversification.title}</h4>
                    <p className="text-sm text-gray-200">{diversification.subtitle}</p>
                  </div>
                </div>
                
                <div className="flex-grow">
                  <p className="text-sm text-gray-200 mb-4">
                    {diversification.description}
                  </p>
                
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-300">Current Allocation:</span>
                      <span className="text-white">{diversification.currentAllocation}%</span>
                    </div>
                
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-300">Recommended:</span>
                      <span className="text-yellow-300">{diversification.recommendedAllocation}</span>
                    </div>
                  </div>
                </div>
                
                <Link
                  to={diversification.exploreLink}
                  className="block w-full bg-yellow-600 hover:bg-yellow-700 text-white py-2 rounded-lg transition-all font-medium hover:shadow-[0_0_25px_rgba(234,179,8,1.0)] hover:border-yellow-400 hover:border-2 border border-transparent focus-visible:shadow-[0_0_25px_rgba(234,179,8,1.0)] focus-visible:border-yellow-400 focus-visible:border-2 text-center"
                >
                  {diversification.exploreText}
                </Link>
              </div>
            </div>
          )}

          {/* Risk Alert Card */}
          {showCards.riskAlert && (
            <div className="bg-slate-700 p-2 rounded-xl">
              <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-5 shadow-xl hover:shadow-[0_0_25px_rgba(239,68,68,0.8)] hover:border-red-400 hover:border-2 border border-red-500 transition-all hover:-translate-y-1 flex flex-col h-[400px]">
                <div className="flex items-center space-x-2 mb-3">
                  <AlertTriangle className={`h-5 w-5 ${getSeverityColor(riskAlert.severity)}`} />
                  <h3 className="font-semibold text-white">Risk Alert</h3>
                </div>
                
                <div className="flex items-center space-x-3 mb-3">
                  <div className="bg-slate-700 rounded-full p-2">
                    <Shield className="h-6 w-6 text-orange-400" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{riskAlert.title}</h4>
                    <p className="text-sm text-gray-400">{riskAlert.subtitle}</p>
                  </div>
                </div>
                
                <div className="flex-grow">
                  <p className="text-sm text-gray-300 mb-4">
                    {riskAlert.description}
                  </p>
                
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Current Exposure:</span>
                      <span className={getSeverityTextColor(riskAlert.severity)}>{riskAlert.currentExposure}%</span>
                    </div>
                
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">Recommended Max:</span>
                      <span className="text-white">{riskAlert.recommendedMax}%</span>
                    </div>
                  </div>
                </div>
                
                <Link
                  to={riskAlert.reviewLink}
                  className="block w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg transition-all font-medium hover:shadow-[0_0_25px_rgba(239,68,68,1.0)] hover:border-red-400 hover:border-2 border border-transparent focus-visible:shadow-[0_0_25px_rgba(239,68,68,1.0)] focus-visible:border-red-400 focus-visible:border-2 text-center"
                >
                  Review Risk Profile
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Trade Modal for Top Buy Recommendation */}
      <QuickTradeModal
        isOpen={isTradeModalOpen}
        onClose={() => setIsTradeModalOpen(false)}
        symbol={topBuy.symbol}
        currentPrice={topBuy.currentPrice * 100} // Convert to CC
        assetName={topBuy.name}
        assetType="character"
      />
    </>
  );
}

export default SmartRecommendationsWidget;