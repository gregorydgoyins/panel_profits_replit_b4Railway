import React from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, BarChart2, Globe, Users, Zap, Crown, Calculator, Target, 
  GraduationCap, FileText, Award, Star, Shield, TrendingUp, Activity
} from 'lucide-react';

interface LearningResearchHubProps {
  className?: string;
}

export function LearningResearchHub({ className = '' }: LearningResearchHubProps) {
  return (
    <div className={`bg-slate-700 p-2 rounded-xl w-full ${className}`}>
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl border border-green-500 hover:shadow-[0_0_25px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2 transition-all">
        <div className="flex items-center space-x-2 flex-shrink-0 pl-0 pr-2 py-1 rounded-md bg-green-900/50 border border-green-700/50 hover:shadow-[0_0_15px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2 border border-transparent transition-all mb-4">
          <BookOpen className="h-4 w-4 text-green-400" />
          <span className="text-xs text-white font-medium">LEARNING & RESEARCH CENTER</span>
        </div>
        
        <div className="grid grid-cols-8 gap-0.5">
          {/* Learning Center */}
          <Link
            to="/learn"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-emerald-900/30 text-emerald-300 hover:bg-emerald-600 hover:text-white"
          >
            <BookOpen className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Learn</span>
          </Link>
          
          {/* Research Reports */}
          <Link
            to="/research"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-red-900/30 text-red-300 hover:bg-red-600 hover:text-white"
          >
            <BarChart2 className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Research</span>
          </Link>
          
          {/* Market Calendar */}
          <Link
            to="/markets/calendar"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-cyan-900/30 text-cyan-300 hover:bg-cyan-600 hover:text-white"
          >
            <Globe className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Calendar</span>
          </Link>
          
          {/* Creator Matrix */}
          <Link
            to="/creators/bios"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-pink-900/30 text-pink-300 hover:bg-pink-600 hover:text-white"
          >
            <Users className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Creators</span>
          </Link>
          
          {/* Locations */}
          <Link
            to="/locations"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-violet-900/30 text-violet-300 hover:bg-violet-600 hover:text-white"
          >
            <Globe className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Locations</span>
          </Link>
          
          {/* Gadgets */}
          <Link
            to="/gadgets"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-amber-900/30 text-amber-300 hover:bg-amber-600 hover:text-white"
          >
            <Zap className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Gadgets</span>
          </Link>
          
          {/* Premium Features */}
          <Link
            to="/simulation"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-gradient-to-r from-yellow-900/30 to-orange-900/30 text-yellow-300 hover:from-yellow-600 hover:to-orange-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Crown className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Premium</span>
          </Link>
          
          {/* Trading Journal */}
          <Link
            to="/portfolio/journal"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-lime-900/30 text-lime-300 hover:bg-lime-600 hover:text-white"
          >
            <BookOpen className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Journal</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LearningResearchHub;