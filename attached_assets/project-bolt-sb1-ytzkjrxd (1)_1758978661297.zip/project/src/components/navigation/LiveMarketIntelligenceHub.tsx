import React from 'react';
import { Link } from 'react-router-dom';
import { 
  TrendingUp, TrendingDown, Activity, Brain, Calendar, Zap, Star, Newspaper, 
  Target as TargetIcon, AlertTriangle, BarChart2, Globe, Crown, PieChart
} from 'lucide-react';
import { useSimulationStore } from '../../store/simulationStore';

interface LiveMarketIntelligenceHubProps {
  className?: string;
}

export function LiveMarketIntelligenceHub({ className = '' }: LiveMarketIntelligenceHubProps) {
  const { liveMetrics } = useSimulationStore();
  
  // Calculate market sentiment for display
  const marketSentiment = liveMetrics?.avgReturn || 0.025;
  const sentimentPercentage = Math.abs(marketSentiment * 100);
  const isMarketPositive = marketSentiment > 0;

  return (
    <div className={`bg-slate-700 p-2 rounded-xl w-full ${className}`}>
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl border border-purple-500 hover:shadow-[0_0_25px_rgba(147,51,234,0.8)] hover:border-purple-400 hover:border-2 transition-all">
        <div className="flex items-center space-x-2 flex-shrink-0 pl-0 pr-2 py-1 rounded-md bg-purple-900/50 border border-purple-700/50 hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent transition-all mb-4">
          <Brain className="h-4 w-4 text-purple-400" />
          <span className="text-xs text-white font-medium">LIVE MARKET INTELLIGENCE HUB</span>
          <div className="ml-auto flex items-center space-x-1">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
            <span className="text-xs text-purple-300">LIVE</span>
          </div>
        </div>
        
        <div className="grid grid-cols-8 gap-0.5">
          {/* Top Gainer Alert */}
          <Link
            to="/characters"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(34,197,94,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-emerald-900/30 text-emerald-300 hover:bg-emerald-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 to-green-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <TrendingUp className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Top Gainer</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">SPDR +8.5%</span>
          </Link>
          
          {/* Biggest Loser Alert */}
          <Link
            to="/characters"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(239,68,68,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-red-900/30 text-red-300 hover:bg-red-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <TrendingDown className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Biggest Drop</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">LEXL -3.2%</span>
          </Link>
          
          {/* Volume Spike Alert */}
          <Link
            to="/markets"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(249,115,22,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-orange-900/30 text-orange-300 hover:bg-orange-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-yellow-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Activity className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Volume Spike</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">ASM300 🔥</span>
          </Link>
          
          {/* AI Confidence Meter */}
          <Link
            to="/ideas"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(6,182,212,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-cyan-900/30 text-cyan-300 hover:bg-cyan-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Brain className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">AI Confidence</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">{(liveMetrics?.aiConfidence || 87.5).toFixed(0)}% 🤖</span>
          </Link>
          
          {/* Market Fear & Greed Index */}
          <Link
            to="/simulation"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(245,158,11,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-amber-900/30 text-amber-300 hover:bg-amber-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 to-yellow-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Zap className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Fear & Greed</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">
              {isMarketPositive ? 'GREED' : 'FEAR'} {sentimentPercentage.toFixed(0)}
            </span>
          </Link>
          
          {/* Breaking News Alert */}
          <Link
            to="/news"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(236,72,153,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-pink-900/30 text-pink-300 hover:bg-pink-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-pink-500/10 to-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Newspaper className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Breaking News</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">Marvel Q3 📈</span>
          </Link>
          
          {/* Hot Asset of the Hour */}
          <Link
            to="/key-comics"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(139,92,246,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-violet-900/30 text-violet-300 hover:bg-violet-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Star className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Hot Asset</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">AF15 🔥⚡</span>
          </Link>
          
          {/* Market Volatility */}
          <Link
            to="/technical-analysis"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(99,102,241,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-indigo-900/30 text-indigo-300 hover:bg-indigo-600 hover:text-white relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Activity className="h-5 w-5 mb-1 relative z-10" />
            <span className="text-xs text-center leading-tight relative z-10">Volatility</span>
            <span className="text-xs font-bold text-center leading-tight relative z-10">High 📊</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LiveMarketIntelligenceHub;