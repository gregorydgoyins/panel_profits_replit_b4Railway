import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShoppingCart, DollarSign, PieChart, Calculator, Target, Shield, AlertTriangle, 
  BarChart2, Calendar, Star, TrendingUp, TrendingDown, Activity, Zap, Globe
} from 'lucide-react';

interface TradingDeskHubProps {
  className?: string;
}

export function TradingDeskHub({ className = '' }: TradingDeskHubProps) {
  return (
    <div className={`bg-slate-700 p-2 rounded-xl w-full ${className}`}>
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl border border-orange-500 hover:shadow-[0_0_25px_rgba(249,115,22,0.8)] hover:border-orange-400 hover:border-2 transition-all">
        <div className="flex items-center space-x-2 flex-shrink-0 pl-0 pr-2 py-1 rounded-md bg-slate-700/50 border border-transparent hover:shadow-[0_0_15px_rgba(249,115,22,0.8)] hover:border-orange-400 hover:border-2 transition-all mb-4">
          <DollarSign className="h-4 w-4 text-orange-400" />
          <span className="text-xs text-white font-medium">TRADING PLATFORM</span>
        </div>
        
        <div className="grid grid-cols-8 gap-0.5">
          {/* Buy Assets */}
          <Link
            to="/trading/buy"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-green-900/30 text-green-300 hover:bg-green-600 hover:text-white"
          >
            <ShoppingCart className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Buy Assets</span>
          </Link>
          
          {/* Sell Assets */}
          <Link
            to="/trading/sell"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-red-900/30 text-red-300 hover:bg-red-600 hover:text-white"
          >
            <DollarSign className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Sell Assets</span>
          </Link>
          
          {/* ETFs */}
          <Link
            to="/trading/etfs"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-blue-900/30 text-blue-300 hover:bg-blue-600 hover:text-white"
          >
            <PieChart className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">ETFs</span>
          </Link>
          
          {/* Options */}
          <Link
            to="/trading/options/calls"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-purple-900/30 text-purple-300 hover:bg-purple-600 hover:text-white"
          >
            <Calculator className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Options</span>
          </Link>
          
          {/* Bonds */}
          <Link
            to="/bonds"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-yellow-900/30 text-yellow-300 hover:bg-yellow-600 hover:text-white"
          >
            <Target className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Bonds</span>
          </Link>
          
          {/* Funds */}
          <Link
            to="/funds"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-indigo-900/30 text-indigo-300 hover:bg-indigo-600 hover:text-white"
          >
            <Shield className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Funds</span>
          </Link>
          
          {/* Risk Management */}
          <Link
            to="/portfolio/tools"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-orange-900/30 text-orange-300 hover:bg-orange-600 hover:text-white"
          >
            <AlertTriangle className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Risk Tools</span>
          </Link>
          
          {/* Derivatives */}
          <Link
            to="/trading/derivatives-futures"
            className="flex flex-col items-center justify-center p-3 rounded-lg font-medium transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 border border-transparent min-h-[80px] bg-pink-900/30 text-pink-300 hover:bg-pink-600 hover:text-white"
          >
            <BarChart2 className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Derivatives</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default TradingDeskHub;