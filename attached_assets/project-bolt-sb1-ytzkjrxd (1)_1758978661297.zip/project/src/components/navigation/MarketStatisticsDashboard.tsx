import React from 'react';
import { Link } from 'react-router-dom';
import { 
  TrendingUp, Activity, Users, Brain, Star, BarChart2, Target, Shield,
  DollarSign, Calendar, PieChart, Zap, Globe, AlertTriangle
} from 'lucide-react';
import { useSimulationStore } from '../../store/simulationStore';

interface MarketStatisticsDashboardProps {
  className?: string;
}

export function MarketStatisticsDashboard({ className = '' }: MarketStatisticsDashboardProps) {
  const { liveMetrics } = useSimulationStore();

  return (
    <div className={`bg-slate-700 p-2 rounded-xl w-full ${className}`}>
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl border border-amber-700 hover:shadow-[0_0_25px_rgba(217,119,6,0.8)] hover:border-amber-600 hover:border-2 transition-all">
        <div className="flex items-center space-x-2 flex-shrink-0 pl-0 pr-2 py-1 rounded-md bg-yellow-900/50 border border-transparent hover:shadow-[0_0_15px_rgba(217,119,6,0.8)] hover:border-amber-400 hover:border-2 transition-all mb-4">
          <BarChart2 className="h-4 w-4 text-pink-400" />
          <span className="text-xs text-white font-medium">MARKET STATISTICS DASHBOARD</span>
          <div className="ml-auto flex items-center space-x-1">
            <div className="w-2 h-2 bg-pink-400 rounded-full animate-pulse" />
            <span className="text-xs text-pink-300">LIVE</span>
          </div>
        </div>
        
        <div className="grid grid-cols-8 gap-0.5">
          {/* Market Cap */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-green-900/30 text-green-300 hover:bg-green-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <TrendingUp className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Market Cap</span>
            <span className="text-xs font-bold text-center leading-tight">
              {(liveMetrics?.totalMarketCap || 125000000000) >= 1e12 
                ? `${((liveMetrics?.totalMarketCap || 125000000000) / 1e12).toFixed(1)}T CC`
                : `${((liveMetrics?.totalMarketCap || 125000000000) / 1e9).toFixed(1)}B CC`}
            </span>
          </div>
          
          {/* Volume */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-blue-900/30 text-blue-300 hover:bg-blue-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <Activity className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Volume</span>
            <span className="text-xs font-bold text-center leading-tight">
              {((liveMetrics?.totalTrades || 8547) * 25000) >= 1e9 
                ? `${(((liveMetrics?.totalTrades || 8547) * 25000) / 1e9).toFixed(1)}B CC`
                : `${(((liveMetrics?.totalTrades || 8547) * 25000) / 1e6).toFixed(1)}M CC`}
            </span>
          </div>
          
          {/* Day Traders */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-orange-900/30 text-orange-300 hover:bg-orange-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <Users className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Day Traders</span>
            <span className="text-xs font-bold text-center leading-tight">
              {Math.min(liveMetrics?.activeTradersCount || 2847, liveMetrics?.totalInvestors || 10000)}/{liveMetrics?.totalInvestors || 10000}
            </span>
          </div>
          
          {/* AI Confidence */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-purple-900/30 text-purple-300 hover:bg-purple-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <Brain className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">AI Confidence</span>
            <span className="text-xs font-bold text-center leading-tight">
              {(liveMetrics?.aiConfidence || 87.5).toFixed(0)}% 🤖
            </span>
          </div>
          
          {/* Hot Assets */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-red-900/30 text-red-300 hover:bg-red-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <Star className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Hot Assets</span>
            <span className="text-xs font-bold text-center leading-tight">
              {liveMetrics?.hotAssetsCount || 87}/{liveMetrics?.totalAssetsCount || 291}
            </span>
          </div>
          
          {/* Total Trades */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-cyan-900/30 text-cyan-300 hover:bg-cyan-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <BarChart2 className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Total Trades</span>
            <span className="text-xs font-bold text-center leading-tight">
              {(liveMetrics?.totalTrades || 8547).toLocaleString()}
            </span>
          </div>
          
          {/* Market Sentiment */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-teal-900/30 text-teal-300 hover:bg-teal-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <TrendingUp className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Sentiment</span>
            <span className="text-xs font-bold text-center leading-tight">
              {(liveMetrics?.avgReturn || 0.025) >= 0 ? 'BULL' : 'BEAR'} {Math.abs((liveMetrics?.avgReturn || 0.025) * 100).toFixed(0)}%
            </span>
          </div>
          
          {/* Volatility Index */}
          <div className="flex flex-col items-center justify-center p-3 rounded-lg font-medium border border-transparent min-h-[80px] w-full bg-pink-900/30 text-pink-300 hover:bg-pink-600 hover:text-white hover:shadow-[0_0_15px_rgba(255,255,255,0.8)] hover:border-white hover:border-2 transition-all cursor-default">
            <Activity className="h-5 w-5 mb-1" />
            <span className="text-xs text-center leading-tight">Volatility</span>
            <span className="text-xs font-bold text-center leading-tight">
              {((liveMetrics?.marketVolatility || 0.25) * 100).toFixed(0)}% VIX
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MarketStatisticsDashboard;