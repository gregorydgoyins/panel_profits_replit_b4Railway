import React, { useState, useEffect } from 'react';
import { ChevronRight, Play, Pause } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface HeroSlide {
  id: string;
  image: string;
  alt: string;
  title: string;
  subtitle: string;
  description: string;
  ctaText: string;
  ctaLink: string;
  ctaType?: 'primary' | 'secondary';
  ctaColor?: string;
  rimColor?: string;
}

interface HeroCarouselProps {
  slides?: HeroSlide[];
  autoPlayInterval?: number;
  showControls?: boolean;
  showIndicators?: boolean;
  className?: string;
}

// Default slides with enhanced content
const defaultSlides: HeroSlide[] = [
  {
    id: 'slide-1',
    image: '/images/ai-hero-1.jpg',
    alt: 'Panel Profits Trading Platform',
    title: 'Welcome to Panel Profits',
    subtitle: 'AI-Powered Comic Trading',
    description: 'Experience sophisticated virtual trading of comic book assets including character stocks, creator bonds, publisher securities, and collectible indices. Our platform combines advanced AI market analysis with professional-grade trading tools.',
    ctaText: 'Start Trading Now',
    ctaLink: '/trading',
    ctaType: 'primary',
    ctaColor: 'from-indigo-700 to-purple-700 hover:from-indigo-600 hover:to-purple-600'
  },
  {
    id: 'slide-2',
    image: '/images/ai-hero-3.jpg',
    alt: 'Market Analysis Dashboard',
    title: 'Advanced Market Analysis',
    subtitle: 'Real-Time Intelligence',
    description: 'Our proprietary AI engine continuously analyzes over 500 comic assets using machine learning algorithms that process sentiment analysis, media impact correlation, and market maker behavior with 87% accuracy.',
    ctaText: 'Explore AI Tools',
    ctaLink: '/ideas',
    ctaType: 'primary',
    ctaColor: 'from-green-700 to-emerald-700 hover:from-green-600 hover:to-emerald-600'
  },
  {
    id: 'slide-3',
    image: '/images/ai-hero-4.jpg',
    alt: 'Learning Center',
    title: 'Master Comic Trading',
    subtitle: 'Learn From The Best',
    description: 'Comprehensive educational platform featuring structured courses in comic market fundamentals, advanced options strategies, and portfolio management theory. Progress through certification programs.',
    ctaText: 'Start Learning',
    ctaLink: '/learn',
    ctaType: 'secondary',
    ctaColor: 'from-orange-700 to-red-700 hover:from-orange-600 hover:to-red-600'
  },
  {
    id: 'slide-4',
    image: '/images/ai-hero-5.jpg',
    alt: 'Portfolio Management',
    title: 'Professional Portfolio Tools',
    subtitle: 'Optimize Your Investments',
    description: 'Sophisticated portfolio management system featuring real-time performance attribution, correlation analysis, volatility modeling, and automated rebalancing recommendations.',
    ctaText: 'View Portfolio',
    ctaLink: '/portfolio',
    ctaType: 'primary',
    ctaColor: 'from-purple-700 to-pink-700 hover:from-purple-600 hover:to-pink-600'
  },
  {
    id: 'slide-5',
    image: '/images/ai-hero-6.jpg',
    alt: 'AI Simulation Engine',
    title: 'AI-Powered Market Simulation',
    subtitle: 'Watch 10,000 AI Investors Compete',
    description: 'Advanced market simulation engine featuring up to 10,000 concurrent AI investors with distinct personality archetypes, trading strategies, and risk profiles competing in real-time.',
    ctaText: 'View Simulation',
    ctaLink: '/simulation',
    ctaType: 'primary',
    ctaColor: 'from-cyan-700 to-blue-700 hover:from-cyan-600 hover:to-blue-600'
  },
  {
    id: 'slide-6',
    image: '/images/ai-hero-7.jpg',
    alt: 'Technical Analysis Studio',
    title: 'Professional Charting Tools',
    subtitle: 'Technical Analysis Studio',
    description: 'Comprehensive technical analysis platform featuring advanced charting capabilities, extensive indicator libraries, backtesting suite, and pattern recognition algorithms.',
    ctaText: 'Open Studio',
    ctaLink: '/technical-analysis',
    ctaType: 'secondary',
    ctaColor: 'from-pink-700 to-rose-700 hover:from-pink-600 hover:to-rose-600'
  },
  {
    id: 'slide-7',
    image: '/images/ai-hero-8.jpg',
    alt: 'Create Your Profile',
    title: 'Join the Community',
    subtitle: 'Create Your Trading Profile',
    description: 'Create your professional trading account with advanced security features including two-factor authentication, encrypted data storage, and personalized dashboards.',
    ctaText: 'Create Profile',
    ctaLink: '/register',
    ctaType: 'primary',
    ctaColor: 'from-yellow-700 to-amber-700 hover:from-yellow-600 hover:to-amber-600'
  },
  {
    id: 'slide-8',
    image: '/images/ai-hero-9.jpg',
    alt: 'News & Market Updates',
    title: 'Stay Informed',
    subtitle: 'Breaking Market News',
    description: 'Comprehensive market intelligence platform delivering real-time news analysis, sentiment tracking, and impact assessment across comic industry developments.',
    ctaText: 'Read Latest News',
    ctaLink: '/news',
    ctaType: 'secondary',
    ctaColor: 'from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600'
  },
  {
    id: 'slide-9',
    image: '/images/ai-hero-10.jpg',
    alt: 'Bond & Fund Marketplace',
    title: 'Diversified Investments',
    subtitle: 'Bonds & Funds Marketplace',
    description: 'Access sophisticated investment vehicles including creator-backed bonds with fixed income streams, professionally managed themed funds, and ETFs tracking market indices.',
    ctaText: 'Browse Funds',
    ctaLink: '/funds',
    ctaType: 'primary',
    ctaColor: 'from-violet-700 to-purple-700 hover:from-violet-600 hover:to-purple-600'
  },
  {
    id: 'slide-10',
    image: '/images/ai-hero-11.jpg',
    alt: 'Character Universe',
    title: 'Character Universe',
    subtitle: 'Heroes, Villains & More',
    description: 'Comprehensive character trading platform featuring over 300 tradeable comic character assets spanning Golden Age legends to Modern Age breakouts.',
    ctaText: 'Explore Characters',
    ctaLink: '/characters',
    ctaType: 'secondary',
    ctaColor: 'from-rose-700 to-pink-700 hover:from-rose-600 hover:to-pink-600'
  },
  {
    id: 'slide-11',
    image: '/images/ai-hero-12.jpg',
    alt: 'Creator Spotlight',
    title: 'Creator Marketplace',
    subtitle: 'Invest in Comic Creators',
    description: 'Professional creator investment platform enabling direct investment in comic industry talent through creator stocks, royalty-backed bonds, and intellectual property portfolios.',
    ctaText: 'Meet Creators',
    ctaLink: '/creators',
    ctaType: 'primary',
    ctaColor: 'from-lime-700 to-green-700 hover:from-lime-600 hover:to-green-600'
  },
  {
    id: 'slide-12',
    image: '/images/dmaIZxUzsAriyMVBfUxn--3--0ag3f.jpg',
    alt: 'Market Research Hub',
    title: 'Market Research Hub',
    subtitle: 'Data-Driven Insights',
    description: 'Institutional-grade research platform providing comprehensive market analysis, quantitative modeling, econometric studies, and professional analyst reports.',
    ctaText: 'View Research',
    ctaLink: '/research',
    ctaType: 'secondary',
    ctaColor: 'from-sky-700 to-cyan-700 hover:from-sky-600 hover:to-cyan-600'
  }
];

export function HeroCarousel({
  slides = defaultSlides,
  autoPlayInterval = 20000, // 20 seconds per slide
  showControls = true,
  showIndicators = true,
  className = ''
}: HeroCarouselProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  // Auto-play functionality
  useEffect(() => {
    if (!isPlaying || isHovered) return;

    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, autoPlayInterval);

    return () => clearInterval(interval);
  }, [isPlaying, isHovered, autoPlayInterval, slides.length]);

  // Navigation functions
  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const goToNext = () => {
    setCurrentSlide(prev => (prev + 1) % slides.length);
  };

  const goToPrevious = () => {
    setCurrentSlide(prev => (prev - 1 + slides.length) % slides.length);
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const currentSlideData = slides[currentSlide];

  return (
    <div className={`bg-slate-700 p-2 rounded-xl w-full ${className}`}>
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl shadow-xl border border-indigo-500 hover:shadow-[0_0_40px_rgba(99,102,241,1.0)] hover:border-indigo-300 hover:border-2 transition-all relative overflow-hidden h-[800px]"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="relative w-full h-full">
          {slides.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? 'opacity-100' : 'opacity-0'
              }`}
            >
              {/* Background Image with Ken Burns Effect */}
              <div className="absolute inset-0 overflow-hidden rounded-xl">
                <img
                  src={slide.image}
                  alt={slide.alt}
                  className={`w-full h-full object-cover transition-all duration-[10000ms] ${
                    index === currentSlide 
                      ? index % 3 === 0 
                        ? 'animate-[kenBurnsZoomPan_10s_ease-in-out_infinite_alternate]' 
                        : index % 3 === 1 
                        ? 'animate-[kenBurnsPanZoom_10s_ease-in-out_infinite_alternate]' 
                        : 'animate-[kenBurnsZoomOut_10s_ease-in-out_infinite_alternate]'
                      : 'scale-100'
                  }`}
                  style={{
                    filter: 'brightness(1.2) contrast(1.1) saturate(1.2)'
                  }}
                />
                {/* Enhanced overlay gradient for better text readability */}
                <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-black/40 to-black/30" />
              </div>

              {/* Text Content - CONSISTENT BOTTOM-LEFT POSITIONING FOR ALL SLIDES */}
              <div className="absolute bottom-0 left-0 p-8 pb-20">
                <div className="max-w-2xl">
                  {/* H2 Heading - Largest */}
                  <h2 className="text-4xl md:text-5xl font-bold text-white mb-3 leading-tight" 
                      style={{ textShadow: '2px 2px 8px rgba(0,0,0,0.9), 0 0 15px rgba(0,0,0,0.7)' }}>
                    {slide.title}
                  </h2>
                  
                  {/* H3 Subtitle - Smaller */}
                  <h3 className="text-lg md:text-xl text-indigo-300 mb-4 font-light"
                      style={{ textShadow: '2px 2px 6px rgba(0,0,0,0.8), 0 0 10px rgba(0,0,0,0.6)' }}>
                    {slide.subtitle}
                  </h3>
                  
                  {/* Description Text - Standard */}
                  <p className="text-base md:text-lg text-gray-200 mb-8 leading-relaxed font-light"
                     style={{ textShadow: '1px 1px 4px rgba(0,0,0,0.8), 0 0 8px rgba(0,0,0,0.6)' }}>
                    {slide.description}
                  </p>
                  
                  {/* CTA Button - Order Desk Example Styling */}
                  <Link
                    to={slide.ctaLink}
                    className={`inline-flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold text-lg bg-gradient-to-r ${slide.ctaColor} text-white transform hover:-translate-y-1 hover:scale-105 active:scale-95 active:translate-y-0 focus:outline-none focus:ring-4 focus:ring-white/50 group relative`}
                    style={{
                      border: '2px solid transparent',
                      transition: 'all 0.3s ease-out',
                      boxShadow: '0 0 0 rgba(255,255,255,0)'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.border = '2px solid white';
                      e.currentTarget.style.boxShadow = '0 0 25px rgba(255,255,255,0.8)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.border = '2px solid transparent';
                      e.currentTarget.style.boxShadow = '0 0 0 rgba(255,255,255,0)';
                    }}
                  >
                    <span>{slide.ctaText}</span>
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse group-hover:scale-125 transition-all duration-300" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation Controls - Right Arrow */}
        {showControls && (
          <div className="absolute inset-y-0 right-4 flex items-center">
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                goToNext();
              }}
              className="bg-black/50 hover:bg-black/70 text-white p-4 rounded-full hover:scale-110"
              style={{
                border: '2px solid transparent',
                transition: 'all 0.3s ease-out',
                boxShadow: '0 0 0 rgba(255,255,255,0)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.border = '2px solid white';
                e.currentTarget.style.boxShadow = '0 0 25px rgba(255,255,255,0.8)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.border = '2px solid transparent';
                e.currentTarget.style.boxShadow = '0 0 0 rgba(255,255,255,0)';
              }}
              aria-label="Next slide"
              type="button"
            >
              <ChevronRight className="h-7 w-7" />
            </button>
          </div>
        )}

        {/* Play/Pause Control */}
        <div className="absolute top-6 right-6">
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              togglePlayPause();
            }}
            className="bg-black/50 hover:bg-black/70 text-white p-3 rounded-full hover:scale-110"
            style={{
              border: '2px solid transparent',
              transition: 'all 0.3s ease-out',
              boxShadow: '0 0 0 rgba(255,255,255,0)'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.border = '2px solid white';
              e.currentTarget.style.boxShadow = '0 0 25px rgba(255,255,255,0.8)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.border = '2px solid transparent';
              e.currentTarget.style.boxShadow = '0 0 0 rgba(255,255,255,0)';
            }}
            aria-label={isPlaying ? 'Pause slideshow' : 'Play slideshow'}
            type="button"
          >
            {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>
        </div>

        {/* Slide Indicators - FIXED NAVIGATION */}
        {showIndicators && (
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
            <div className="flex space-x-3">
              {slides.map((slide, index) => (
                <button
                  key={index}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    goToSlide(index);
                  }}
                  className={`w-4 h-4 rounded-full hover:scale-125 ${
                    index === currentSlide
                      ? 'bg-white scale-125'
                      : 'bg-white/50 hover:bg-white/75'
                  }`}
                  style={{
                    border: index === currentSlide ? '2px solid white' : '2px solid transparent',
                    transition: 'all 0.3s ease-out',
                    boxShadow: index === currentSlide ? '0 0 25px rgba(255,255,255,0.8)' : '0 0 0 rgba(255,255,255,0)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.border = '2px solid white';
                    e.currentTarget.style.boxShadow = '0 0 25px rgba(255,255,255,0.8)';
                  }}
                  onMouseLeave={(e) => {
                    if (index !== currentSlide) {
                      e.currentTarget.style.border = '2px solid transparent';
                      e.currentTarget.style.boxShadow = '0 0 0 rgba(255,255,255,0)';
                    }
                  }}
                  aria-label={`Go to slide ${index + 1}`}
                  type="button"
                />
              ))}
            </div>
          </div>
        )}

        {/* Slide Counter */}
        <div 
          className="absolute bottom-8 right-8 bg-black/50 backdrop-blur-sm px-4 py-2 rounded-full"
          style={{
            border: '2px solid transparent',
            transition: 'all 0.3s ease-out',
            boxShadow: '0 0 0 rgba(255,255,255,0)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.border = '2px solid white';
            e.currentTarget.style.boxShadow = '0 0 25px rgba(255,255,255,0.8)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.border = '2px solid transparent';
            e.currentTarget.style.boxShadow = '0 0 0 rgba(255,255,255,0)';
          }}
        >
          <span className="text-white text-sm font-medium">
            {currentSlide + 1} / {slides.length}
          </span>
        </div>
      </div>
    </div>
  );
}

export default HeroCarousel;