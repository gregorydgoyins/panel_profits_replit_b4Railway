import React, { useState } from 'react';
import { Users, Award, Calendar, BookOpen, Star, TrendingUp, Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { allCreators } from '../../data/creatorData';

export function CreatorBiosPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [sortBy, setSortBy] = useState('popularity');

  const roles = ['all', 'Writer', 'Artist', 'Cover Artist', 'Artist/Writer', 'Artist/Executive'];

  const filteredCreators = allCreators
    .filter(creator => {
      const matchesSearch = creator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           creator.symbol.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = selectedRole === 'all' || creator.role === selectedRole;
      return matchesSearch && matchesRole;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'popularity':
          return b.popularity - a.popularity;
        case 'awards':
          return b.awards - a.awards;
        case 'experience':
          return b.yearsActive - a.yearsActive;
        case 'alphabetical':
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });

  const getCreatorBio = (creator: any) => {
    const bios: Record<string, string> = {
      'TMFS': `Todd McFarlane revolutionized the comic industry in the 1990s with his dynamic art style and entrepreneurial spirit. After co-creating Venom and achieving massive success on Spider-Man, he left Marvel to co-found Image Comics, where he created Spawn - one of the most successful independent comics ever. McFarlane's business acumen extends beyond comics into toys, animation, and media production. His company, McFarlane Toys, has become a major player in the collectibles market. Known for his detailed, kinetic art style and willingness to push creative boundaries, McFarlane continues to influence both the artistic and business sides of the comic industry.`,
      
      'JLES': `Jim Lee is one of the most influential artists and executives in modern comics. Rising to fame in the 1990s with his work on X-Men, Lee co-founded Image Comics and created WildStorm Productions. His detailed, dynamic art style helped define the look of 1990s comics and continues to influence artists today. As DC's Chief Creative Officer and Publisher, Lee oversees the creative direction of one of the industry's biggest publishers. His business leadership combined with artistic excellence makes him a unique figure who bridges creative vision with corporate strategy. Lee's covers and character designs remain among the most sought-after in the industry.`,
      
      'DCTS': `Donny Cates has emerged as one of the most exciting voices in modern comics, known for his cosmic horror sensibilities and character-driven storytelling. His work on titles like Venom, Thor, and Hulk has redefined these characters for a new generation. Cates excels at blending intimate character moments with universe-shaking events, creating stories that resonate on both personal and epic scales. His creator-owned work, including God Country and Buzzkill, showcases his range beyond superhero comics. With a background in horror and a deep understanding of comic history, Cates brings fresh perspectives to established characters while creating compelling new mythologies.`,
      
      'ARTS': `Stanley "Artgerm" Lau has become one of the most recognizable cover artists in comics, known for his stunning portraits and pin-up style artwork. His covers grace titles from both Marvel and DC, featuring iconic characters rendered with incredible detail and beauty. Artgerm's background in video game art and digital illustration brings a unique aesthetic to comic covers that stands out on shelves. His work consistently drives variant cover sales and has made him a fan-favorite artist. Beyond comics, his art has influenced character design in games, animation, and collectibles, making him a crossover success between different entertainment mediums.`,
      
      'BMBS': `Brian Michael Bendis transformed modern comics with his naturalistic dialogue and character-focused storytelling. His work on Ultimate Spider-Man redefined the character for a new generation, while his Avengers run brought street-level sensibilities to Marvel's premier team. Bendis pioneered the "decompressed" storytelling style and helped establish the modern comic book writing template. His creator-owned work, including Powers and Scarlet, showcases his crime fiction influences. After a legendary run at Marvel, his move to DC brought fresh perspectives to Superman and the Legion of Super-Heroes. Bendis continues to mentor new creators while pushing storytelling boundaries.`,
      
      'FSTS': `Fiona Staples has redefined what comic art can be with her work on the critically acclaimed series Saga. Her ability to blend science fiction, fantasy, and intimate human drama in her artwork has earned widespread critical praise and industry recognition. Staples' character designs are both alien and relatable, creating a visual language that perfectly complements Brian K. Vaughan's writing. Her background in animation brings a cinematic quality to her comic work, with each panel feeling like a frame from an animated film. Staples represents the new generation of comic artists who are expanding the medium's artistic possibilities while maintaining strong storytelling fundamentals.`
    };
    
    return bios[creator.symbol] || `${creator.name} is a ${creator.role.toLowerCase()} with ${creator.yearsActive} years of experience in the comic industry. Known for their distinctive style and professional approach, they have earned ${creator.awards} industry awards and maintain a ${creator.popularity}% popularity rating among fans and critics. Their recent works include ${creator.recentWorks.slice(0, 2).join(' and ')}, showcasing their continued relevance and creative evolution in the modern comic landscape.`;
  };

  const getCareerHighlights = (creator: any) => {
    const highlights: Record<string, string[]> = {
      'TMFS': [
        'Co-created Venom, one of Marvel\'s most popular characters',
        'Founded Image Comics, revolutionizing creator rights',
        'Created Spawn, longest-running independent comic series',
        'Built McFarlane Toys into major collectibles company',
        'Pioneered detailed, kinetic art style in 1990s'
      ],
      'JLES': [
        'Redefined X-Men with iconic 1990s art style',
        'Co-founded Image Comics and WildStorm Productions',
        'Serves as DC\'s Chief Creative Officer and Publisher',
        'Created WildC.A.T.s and other WildStorm universe characters',
        'Mentored countless artists through his editorial leadership'
      ],
      'DCTS': [
        'Revitalized Venom with cosmic horror elements',
        'Redefined Thor mythology with epic storytelling',
        'Created acclaimed horror series God Country',
        'Brought fresh perspective to classic Marvel characters',
        'Established himself as premier cosmic horror writer'
      ],
      'ARTS': [
        'Became premier cover artist for Marvel and DC',
        'Pioneered digital pin-up style in comics',
        'Influenced character design across multiple media',
        'Consistently drives variant cover sales',
        'Bridged gap between comic and video game art'
      ],
      'BMBS': [
        'Created Ultimate Spider-Man, redefining the character',
        'Wrote definitive Avengers run for over a decade',
        'Pioneered modern comic book dialogue style',
        'Created Powers, influential creator-owned series',
        'Mentored new generation of comic writers'
      ],
      'FSTS': [
        'Co-created Saga, one of most acclaimed modern comics',
        'Redefined science fiction comic art',
        'Earned multiple Eisner and Harvey Awards',
        'Influenced new generation of comic artists',
        'Brought cinematic quality to comic storytelling'
      ]
    };
    
    return highlights[creator.symbol] || [
      `${creator.yearsActive} years of professional comic experience`,
      `${creator.awards} industry awards and recognitions`,
      `${creator.popularity}% fan approval rating`,
      `Recent work on ${creator.recentWorks[0]}`,
      `Upcoming project: ${creator.nextProject || 'TBA'}`
    ];
  };

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Creators', path: '/creators' },
        { name: 'Creator Biographies' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Users className="h-8 w-8 text-indigo-400" />
          <h1 className="text-3xl font-bold text-white">Creator Biographies & Profiles</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Award className="h-5 w-5" />
          <span className="text-sm">Industry legends and rising stars</span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search creators..."
              className="pl-10 pr-4 py-2 w-full bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="flex-1 bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 px-3 py-2"
            >
              {roles.map(role => (
                <option key={role} value={role}>
                  {role === 'all' ? 'All Roles' : role}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-gray-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="flex-1 bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 px-3 py-2"
            >
              <option value="popularity">Popularity</option>
              <option value="awards">Awards</option>
              <option value="experience">Experience</option>
              <option value="alphabetical">A-Z</option>
            </select>
          </div>

          <div className="text-sm text-gray-400 flex items-center justify-end">
            {filteredCreators.length} creators found
          </div>
        </div>
      </div>

      {/* Creator Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredCreators.map((creator) => (
          <div key={creator.id} className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 border border-slate-700/50 hover:border-indigo-500/50">
            <div className="flex items-start space-x-4">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-lg">
                  {creator.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xl font-bold text-white">{creator.name}</h2>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span className="text-yellow-400 font-medium">{creator.popularity}%</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 mb-3">
                  <span className="px-2 py-1 bg-indigo-900/50 text-indigo-200 rounded-full text-xs font-medium">
                    {creator.role}
                  </span>
                  <div className="flex items-center space-x-1 text-gray-400 text-sm">
                    <Calendar className="h-3 w-3" />
                    <span>{creator.yearsActive} years</span>
                  </div>
                  <div className="flex items-center space-x-1 text-gray-400 text-sm">
                    <Award className="h-3 w-3" />
                    <span>{creator.awards} awards</span>
                  </div>
                </div>
                
                <p className="text-gray-300 text-sm leading-relaxed mb-4 line-clamp-3">
                  {getCreatorBio(creator)}
                </p>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="text-white font-medium mb-2">Career Highlights</h4>
                    <ul className="space-y-1">
                      {getCareerHighlights(creator).slice(0, 3).map((highlight, index) => (
                        <li key={index} className="text-gray-300 text-sm flex items-start space-x-2">
                          <span className="text-indigo-400 mt-1">•</span>
                          <span>{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-white font-medium mb-2">Recent Works</h4>
                    <div className="flex flex-wrap gap-2">
                      {creator.recentWorks.slice(0, 3).map((work, index) => (
                        <span key={index} className="px-2 py-1 bg-slate-700/50 text-gray-300 rounded text-xs">
                          {work}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-3 border-t border-slate-700/50">
                    <div className="text-sm text-gray-400">
                      Stock Symbol: <span className="text-white font-medium">{creator.symbol}</span>
                    </div>
                    <Link
                      to={`/creator/${creator.symbol.toLowerCase()}`}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors duration-200 hover:shadow-lg"
                    >
                      View Full Profile
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Industry Impact Section */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Industry Impact & Legacy</h2>
            <p className="text-white/90 mb-4">
              These creators have shaped the comic industry through their artistic vision, storytelling innovation, and business leadership.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-white/80 text-sm">
              <div>
                <strong>Artistic Innovation:</strong> Pushing visual boundaries and defining new art styles
              </div>
              <div>
                <strong>Storytelling Evolution:</strong> Creating new narrative techniques and character development
              </div>
              <div>
                <strong>Industry Leadership:</strong> Founding companies and mentoring the next generation
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <BookOpen className="h-24 w-24 text-white/20" />
          </div>
        </div>
      </div>

      {filteredCreators.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No creators found</h3>
          <p className="text-gray-400">Try adjusting your search criteria or filters.</p>
        </div>
      )}
    </div>
  );
}

export default CreatorBiosPage;