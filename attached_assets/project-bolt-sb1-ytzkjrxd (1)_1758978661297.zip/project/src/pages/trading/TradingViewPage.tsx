import React, { useState } from 'react';
import { BarChart2, TrendingUp, Activity, Target, Zap, Eye, Settings, Monitor } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function TradingViewPage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedAsset, setSelectedAsset] = useState('ASM300');
  const [selectedTimeframe, setSelectedTimeframe] = useState('1D');
  const [selectedIndicators, setSelectedIndicators] = useState(['SMA', 'RSI']);

  const assets = [
    { symbol: 'ASM300', name: 'Amazing Spider-Man #300', price: 2650, change: 8.5 },
    { symbol: 'BATM', name: 'Batman', price: 4462, change: 6.2 },
    { symbol: 'SPDR', name: 'Spider-Man', price: 3686, change: 5.3 },
    { symbol: 'TMFS', name: 'Todd McFarlane', price: 1958, change: 5.8 },
    { symbol: 'AF15', name: 'Amazing Fantasy #15', price: 1800000, change: 5.57 }
  ];

  const timeframes = ['1m', '5m', '15m', '30m', '1H', '4H', '1D', '1W', '1M'];
  
  const indicators = [
    { id: 'SMA', name: 'Simple Moving Average', category: 'Trend' },
    { id: 'EMA', name: 'Exponential Moving Average', category: 'Trend' },
    { id: 'RSI', name: 'Relative Strength Index', category: 'Momentum' },
    { id: 'MACD', name: 'MACD', category: 'Momentum' },
    { id: 'BB', name: 'Bollinger Bands', category: 'Volatility' },
    { id: 'VWAP', name: 'Volume Weighted Average Price', category: 'Volume' },
    { id: 'STOCH', name: 'Stochastic Oscillator', category: 'Momentum' },
    { id: 'ATR', name: 'Average True Range', category: 'Volatility' }
  ];

  const currentAsset = assets.find(a => a.symbol === selectedAsset) || assets[0];

  // Mock chart data points for visualization
  const generateChartData = () => {
    const basePrice = currentAsset.price;
    const points = [];
    for (let i = 0; i < 100; i++) {
      const variation = (Math.random() - 0.5) * 0.1;
      const price = basePrice * (1 + variation + (currentAsset.change / 100) * (i / 100));
      points.push({
        time: i,
        price: price,
        volume: Math.random() * 10000 + 5000
      });
    }
    return points;
  };

  const chartData = generateChartData();

  const technicalAnalysis = {
    trend: 'Bullish',
    support: currentAsset.price * 0.95,
    resistance: currentAsset.price * 1.08,
    rsi: 67.3,
    macd: 'Bullish Crossover',
    volume: 'Above Average',
    recommendation: 'Buy'
  };

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Trading', path: '/trading' },
        { name: 'Trading View' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <BarChart2 className="h-8 w-8 text-blue-400" />
          <h1 className="text-3xl font-bold text-white">Advanced Trading View</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Monitor className="h-5 w-5" />
          <span className="text-sm">Professional charting platform</span>
        </div>
      </div>

      {/* Asset Selection and Controls */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div>
              <label className="text-gray-400 text-sm">Asset</label>
              <select
                value={selectedAsset}
                onChange={(e) => setSelectedAsset(e.target.value)}
                className="block bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 px-3 py-2"
              >
                {assets.map(asset => (
                  <option key={asset.symbol} value={asset.symbol}>
                    {asset.symbol} - {asset.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-gray-400 text-sm">Timeframe</label>
              <div className="flex space-x-1 mt-1">
                {timeframes.map(tf => (
                  <button
                    key={tf}
                    onClick={() => setSelectedTimeframe(tf)}
                    className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                      selectedTimeframe === tf
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-700/50 text-gray-300 hover:bg-slate-600/50'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="text-right">
              <p className="text-2xl font-bold text-white">
                CC {currentAsset.price >= 1000000 ? 
                  `${(currentAsset.price / 1000000).toFixed(2)}M` : 
                  currentAsset.price.toLocaleString()
                }
              </p>
              <div className="flex items-center space-x-1">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <span className="text-green-400 font-medium">+{currentAsset.change}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chart Area */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">{currentAsset.name} Chart</h2>
          <div className="flex items-center space-x-2">
            <Settings className="h-5 w-5 text-gray-400" />
            <span className="text-gray-400 text-sm">Chart Settings</span>
          </div>
        </div>
        
        {/* Mock Chart Visualization */}
        <div className="bg-slate-900/50 rounded-lg p-4 h-96 relative">
          <div className="absolute inset-4">
            <svg className="w-full h-full" viewBox="0 0 800 300">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="40" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 30" fill="none" stroke="#374151" strokeWidth="0.5" opacity="0.3"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
              
              {/* Price line */}
              <polyline
                fill="none"
                stroke="#3B82F6"
                strokeWidth="2"
                points={chartData.map((point, index) => 
                  `${(index / chartData.length) * 800},${300 - ((point.price - currentAsset.price * 0.9) / (currentAsset.price * 0.2)) * 300}`
                ).join(' ')}
              />
              
              {/* Volume bars */}
              {chartData.slice(0, 50).map((point, index) => (
                <rect
                  key={index}
                  x={index * 16}
                  y={250}
                  width="12"
                  height={(point.volume / 15000) * 50}
                  fill="#6B7280"
                  opacity="0.6"
                />
              ))}
            </svg>
            
            {/* Chart overlays */}
            <div className="absolute top-4 left-4 bg-slate-800/80 rounded-lg p-3">
              <div className="text-white text-sm space-y-1">
                <div>Open: CC {(currentAsset.price * 0.98).toLocaleString()}</div>
                <div>High: CC {(currentAsset.price * 1.05).toLocaleString()}</div>
                <div>Low: CC {(currentAsset.price * 0.95).toLocaleString()}</div>
                <div>Close: CC {currentAsset.price.toLocaleString()}</div>
              </div>
            </div>
            
            <div className="absolute top-4 right-4 bg-slate-800/80 rounded-lg p-3">
              <div className="text-white text-sm space-y-1">
                <div>Volume: {((liveMetrics?.totalTrades || 8547) * 25).toLocaleString()}</div>
                <div>Avg Volume: {((liveMetrics?.totalTrades || 8547) * 20).toLocaleString()}</div>
                <div className="text-green-400">+25% vs avg</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Indicators */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
          <h2 className="text-xl font-bold text-white mb-6">Technical Indicators</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {indicators.filter(ind => selectedIndicators.includes(ind.id)).map((indicator, index) => (
              <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-medium text-white">{indicator.name}</h3>
                  <span className="px-2 py-1 bg-blue-900/50 text-blue-200 rounded text-xs">
                    {indicator.category}
                  </span>
                </div>
                <div className="space-y-2">
                  {indicator.id === 'RSI' && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-400">RSI (14):</span>
                        <span className="text-white font-medium">{technicalAnalysis.rsi}</span>
                      </div>
                      <div className="w-full bg-slate-600 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${technicalAnalysis.rsi}%` }}
                        />
                      </div>
                      <p className="text-gray-300 text-xs">Neutral zone (30-70)</p>
                    </>
                  )}
                  {indicator.id === 'SMA' && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-400">SMA (20):</span>
                        <span className="text-white font-medium">CC {(currentAsset.price * 0.97).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">SMA (50):</span>
                        <span className="text-white font-medium">CC {(currentAsset.price * 0.94).toLocaleString()}</span>
                      </div>
                      <p className="text-green-400 text-xs">Price above both SMAs - Bullish</p>
                    </>
                  )}
                  {indicator.id === 'MACD' && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-400">MACD:</span>
                        <span className="text-green-400 font-medium">Bullish</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Signal:</span>
                        <span className="text-green-400 font-medium">Buy</span>
                      </div>
                      <p className="text-green-400 text-xs">MACD line above signal line</p>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <h3 className="font-medium text-white mb-3">Add Indicators</h3>
            <div className="flex flex-wrap gap-2">
              {indicators.filter(ind => !selectedIndicators.includes(ind.id)).map((indicator) => (
                <button
                  key={indicator.id}
                  onClick={() => setSelectedIndicators([...selectedIndicators, indicator.id])}
                  className="px-3 py-1 bg-slate-700/50 text-gray-300 rounded text-sm hover:bg-slate-600/50 transition-colors"
                >
                  + {indicator.name}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
          <h2 className="text-xl font-bold text-white mb-6">Technical Analysis</h2>
          <div className="space-y-4">
            <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <h3 className="font-medium text-white mb-3">Overall Trend</h3>
              <div className="flex items-center space-x-2 mb-2">
                <TrendingUp className="h-5 w-5 text-green-400" />
                <span className="text-green-400 font-semibold">{technicalAnalysis.trend}</span>
              </div>
              <p className="text-gray-300 text-sm">Strong upward momentum with increasing volume</p>
            </div>
            
            <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <h3 className="font-medium text-white mb-3">Key Levels</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Support:</span>
                  <span className="text-green-400">CC {technicalAnalysis.support.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Resistance:</span>
                  <span className="text-red-400">CC {technicalAnalysis.resistance.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <h3 className="font-medium text-white mb-3">Signals</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">RSI:</span>
                  <span className="text-yellow-400">Neutral</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">MACD:</span>
                  <span className="text-green-400">Bullish</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Volume:</span>
                  <span className="text-green-400">Strong</span>
                </div>
              </div>
            </div>
            
            <div className={`p-4 rounded-lg border ${
              technicalAnalysis.recommendation === 'Buy' ? 'bg-green-900/30 border-green-700/30' :
              technicalAnalysis.recommendation === 'Sell' ? 'bg-red-900/30 border-red-700/30' :
              'bg-yellow-900/30 border-yellow-700/30'
            }`}>
              <div className="flex items-center space-x-2 mb-2">
                <Target className="h-5 w-5 text-green-400" />
                <h3 className="font-medium text-white">Recommendation</h3>
              </div>
              <p className={`font-semibold ${
                technicalAnalysis.recommendation === 'Buy' ? 'text-green-400' :
                technicalAnalysis.recommendation === 'Sell' ? 'text-red-400' :
                'text-yellow-400'
              }`}>
                {technicalAnalysis.recommendation}
              </p>
              <p className="text-gray-300 text-sm mt-1">
                Based on current technical indicators and market momentum
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Trading Tools */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Quick Trading Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="bg-green-600 hover:bg-green-700 text-white p-4 rounded-lg font-medium transition-colors">
            <div className="flex items-center justify-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Place Buy Order</span>
            </div>
          </button>
          
          <button className="bg-red-600 hover:bg-red-700 text-white p-4 rounded-lg font-medium transition-colors">
            <div className="flex items-center justify-center space-x-2">
              <TrendingUp className="h-5 w-5 rotate-180" />
              <span>Place Sell Order</span>
            </div>
          </button>
          
          <button className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-lg font-medium transition-colors">
            <div className="flex items-center justify-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>Add to Watchlist</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

export default TradingViewPage;