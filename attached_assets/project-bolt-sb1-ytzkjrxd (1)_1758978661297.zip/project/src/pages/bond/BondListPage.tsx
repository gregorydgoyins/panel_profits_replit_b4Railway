import React from 'react';
import { BondList } from '../../components/bond/BondList';

export function BondListPage() {
  return <BondList />;
}

export default BondListPage;