import React from 'react';
import { BondDetails } from '../../components/bond/BondDetails';

export function BondDetailsPage() {
  return <BondDetails />;
}

export default BondDetailsPage;