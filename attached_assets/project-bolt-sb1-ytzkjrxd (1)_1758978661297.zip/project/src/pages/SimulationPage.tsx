import React, { useState, useEffect } from 'react';
import { 
  Users, Play, Pause, Square, RotateCcw, Settings, 
  BarChart2, TrendingUp, TrendingDown, Activity, 
  Brain, Target, Award, Clock, DollarSign
} from 'lucide-react';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { useSimulationStore } from '../store/simulationStore';
import { SimulationSettings } from '../components/SimulationSettings';
import { InvestorArchetype } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

export function SimulationPage() {
  const {
    isInitialized,
    isRunning,
    isPaused,
    currentStep,
    maxSteps,
    config,
    investors,
    marketState,
    results,
    liveMetrics,
    initializeSimulation,
    startSimulation,
    pauseSimulation,
    stopSimulation,
    resetSimulation,
    getProgress
  } = useSimulationStore();

  const [showSettings, setShowSettings] = useState(false);

  // Initialize simulation on component mount
  useEffect(() => {
    if (!isInitialized) {
      initializeSimulation();
    }
  }, [isInitialized, initializeSimulation]);

  const progress = getProgress();

  // Get archetype distribution
  const archetypeDistribution = investors.reduce((acc, investor) => {
    const archetypeId = investor.archetype.id;
    acc[archetypeId] = (acc[archetypeId] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const archetypeChartData = Object.entries(archetypeDistribution).map(([id, count]) => ({
    name: investors.find(inv => inv.archetype.id === id)?.archetype.name || id,
    value: count,
    percentage: (count / investors.length) * 100
  }));

  // Generate performance data for chart
  const performanceChartData = investors
    .map((investor, index) => ({
      name: investor.archetype.name,
      return: investor.performanceMetrics.totalReturn * 100,
      winRate: investor.performanceMetrics.winRate * 100,
      trades: investor.performanceMetrics.totalTrades,
      id: investor.id
    }))
    .slice(0, 20); // Show top 20 for readability

  const COLORS = ['#818cf8', '#22c55e', '#eab308', '#ec4899', '#14b8a6', '#f97316'];

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[{ name: 'Market Simulation' }]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Brain className="h-8 w-8 text-purple-400" />
          <h1 className="text-3xl font-bold text-white">AI Investor Simulation</h1>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="flex items-center space-x-2 bg-slate-700/50 hover:bg-slate-700 text-gray-300 hover:text-white px-4 py-2 rounded-lg transition-colors"
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </button>
        </div>
      </div>

      {/* Simulation Control Panel */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white mb-2">Simulation Control</h2>
            <p className="text-gray-300">
              {config.numInvestors.toLocaleString()} AI investors ({investors.length} initialized) • {Object.keys(marketState?.currentPrices || {}).length} assets • {currentStep.toLocaleString()}/{maxSteps.toLocaleString()} steps
            </p>
            {config.numInvestors > 5000 && (
              <p className="text-yellow-400 text-sm mt-1">
                ⚡ High-performance mode with Web Workers enabled
              </p>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            {!isRunning && !isPaused && (
              <button
                onClick={() => isInitialized ? startSimulation() : initializeSimulation()}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <Play className="h-5 w-5" />
                <span>{isInitialized ? 'Start' : 'Initialize'}</span>
              </button>
            )}
            
            {isRunning && (
              <button
                onClick={pauseSimulation}
                className="flex items-center space-x-2 bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <Pause className="h-5 w-5" />
                <span>Pause</span>
              </button>
            )}
            
            {isPaused && (
              <button
                onClick={startSimulation}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition-colors"
              >
                <Play className="h-5 w-5" />
                <span>Resume</span>
              </button>
            )}
            
            <button
              onClick={stopSimulation}
              disabled={!isRunning && !isPaused}
              className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white px-6 py-3 rounded-lg transition-colors"
            >
              <Square className="h-5 w-5" />
              <span>Stop</span>
            </button>
            
            <button
              onClick={resetSimulation}
              className="flex items-center space-x-2 bg-slate-600 hover:bg-slate-700 text-white px-6 py-3 rounded-lg transition-colors"
            >
              <RotateCcw className="h-5 w-5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400">Simulation Progress</span>
            <span className="text-white font-medium">{progress.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-slate-700 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-purple-600 to-indigo-600 h-3 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400 mt-1">
            <span>Step {currentStep.toLocaleString()}</span>
            <span>{maxSteps.toLocaleString()} steps total</span>
          </div>
        </div>

        {/* Live Metrics */}
        {liveMetrics && (
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Total Trades</p>
              <p className="text-xl font-bold text-white">{liveMetrics.totalTrades.toLocaleString()}</p>
            </div>
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Avg Return</p>
              <p className={`text-xl font-bold ${liveMetrics.avgReturn >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {liveMetrics.avgReturn >= 0 ? '+' : ''}{(liveMetrics.avgReturn * 100).toFixed(1)}%
              </p>
            </div>
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Market Volatility</p>
              <p className="text-xl font-bold text-white">{(liveMetrics.marketVolatility * 100).toFixed(1)}%</p>
            </div>
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Top Performer</p>
              <p className="text-xl font-bold text-green-400">{liveMetrics.activeTradersCount.toLocaleString()}</p>
            </div>
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Worst Performer</p>
              <p className="text-xl font-bold text-orange-400">{liveMetrics.hotAssetsCount}</p>
            </div>
            <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
              <p className="text-sm text-gray-400">Most Active</p>
              <p className="text-xl font-bold text-indigo-400">{liveMetrics.mostActiveAsset || 'N/A'}</p>
            </div>
          </div>
        )}
      </div>

      {/* Settings Modal */}
      <SimulationSettings 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
      />

      {/* Investor Archetypes Overview */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Investor Archetypes</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Archetype Distribution */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={archetypeChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percentage }) => `${name} (${percentage.toFixed(0)}%)`}
                  >
                    {archetypeChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [`${value} investors`, 'Count']}
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: 'none',
                      borderRadius: '0.5rem',
                      color: '#e2e8f0'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
          
          {/* Archetype Descriptions */}
          <div className="space-y-3">
            {config.numInvestors > 0 && 
              Array.from(new Set(investors.map(inv => inv.archetype.id)))
                .map(archetypeId => {
                  const archetype = investors.find(inv => inv.archetype.id === archetypeId)?.archetype;
                  const count = archetypeDistribution[archetypeId];
                  
                  if (!archetype) return null;
                  
                  return (
                    <div key={archetypeId} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-white">{archetype.name}</h4>
                        <span className="text-sm text-indigo-400">{count?.toLocaleString() || 0} investors</span>
                      </div>
                      <p className="text-sm text-gray-300 mb-2">{archetype.description}</p>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Risk:</span>
                          <span className={`${
                            archetype.riskTolerance === 'high' ? 'text-red-400' :
                            archetype.riskTolerance === 'medium' ? 'text-yellow-400' :
                            'text-green-400'
                          }`}>
                            {archetype.riskTolerance.charAt(0).toUpperCase() + archetype.riskTolerance.slice(1)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Strategy:</span>
                          <span className="text-white">{archetype.strategy.replace('-', ' ')}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
            }
          </div>
        </div>
      </div>

      {/* Real-time Performance Charts */}
      {isRunning && performanceChartData.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Investor Performance */}
          <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
            <h3 className="text-lg font-bold text-white mb-4">Investor Performance (Top 20)</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={performanceChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                  <YAxis stroke="#94a3b8" tickFormatter={(value) => `${value.toFixed(0)}%`} />
                  <Tooltip
                    formatter={(value: number) => [`${value.toFixed(1)}%`, 'Return']}
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: 'none',
                      borderRadius: '0.5rem',
                      color: '#e2e8f0'
                    }}
                  />
                  <Bar dataKey="return" radius={[4, 4, 0, 0]}>
                    {performanceChartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.return >= 0 ? '#22c55e' : '#ef4444'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Market State Visualization */}
          <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
            <h3 className="text-lg font-bold text-white mb-4">Market State</h3>
            {marketState && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
                    <p className="text-sm text-gray-400">Market Sentiment</p>
                    <div className="flex items-center space-x-2">
                      {marketState.marketSentiment >= 0 ? (
                        <TrendingUp className="h-4 w-4 text-green-400" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-400" />
                      )}
                      <span className={`font-bold ${marketState.marketSentiment >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {(marketState.marketSentiment * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
                    <p className="text-sm text-gray-400">Volatility Regime</p>
                    <p className={`font-bold ${
                      marketState.volatilityRegime === 'extreme' ? 'text-red-400' :
                      marketState.volatilityRegime === 'high' ? 'text-yellow-400' :
                      marketState.volatilityRegime === 'normal' ? 'text-green-400' :
                      'text-blue-400'
                    }`}>
                      {marketState.volatilityRegime.charAt(0).toUpperCase() + marketState.volatilityRegime.slice(1)}
                    </p>
                  </div>
                </div>

                <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
                  <p className="text-sm text-gray-400">Market Trend</p>
                  <div className="flex items-center space-x-2">
                    {marketState.marketTrend === 'bull' ? (
                      <TrendingUp className="h-5 w-5 text-green-400" />
                    ) : marketState.marketTrend === 'bear' ? (
                      <TrendingDown className="h-5 w-5 text-red-400" />
                    ) : (
                      <Activity className="h-5 w-5 text-yellow-400" />
                    )}
                    <span className={`font-bold ${
                      marketState.marketTrend === 'bull' ? 'text-green-400' :
                      marketState.marketTrend === 'bear' ? 'text-red-400' :
                      'text-yellow-400'
                    }`}>
                      {marketState.marketTrend.charAt(0).toUpperCase() + marketState.marketTrend.slice(1)} Market
                    </span>
                  </div>
                </div>

                {marketState.marketEvents && marketState.marketEvents.length > 0 && (
                  <div className="bg-slate-700/50 p-3 rounded-lg border border-slate-600/50">
                    <p className="text-sm text-gray-400 mb-2">Active Market Events</p>
                    <div className="space-y-1">
                      {marketState.marketEvents.slice(0, 3).map((impact, index) => (
                        <div key={index} className="text-xs text-white">
                          <span className="text-yellow-400">•</span> Market event {index + 1}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}