import React, { useState } from 'react';
import { 
  TrendingUp, BarChart3, Settings, Eye, EyeOff, Activity, 
  Calendar, Clock, DollarSign, Target, Zap, LineChart,
  PieChart, BarChart2, Layers, Filter, Search, Play,
  BookOpen, TestTube, Briefcase
} from 'lucide-react';
import HighchartsTechnicalChart from '../components/charts/HighchartsTechnicalChart';

interface TechnicalIndicators {
  // Moving Averages
  sma20: boolean;
  sma30: boolean;
  sma50: boolean;
  sma60: boolean;
  sma90: boolean;
  sma200: boolean;
  ema12: boolean;
  ema26: boolean;
  
  // Bollinger Bands
  bollingerBands: boolean;
  
  // MACD
  macd: boolean;
  
  // Oscillators
  rsi: boolean;
  stochastic: boolean;
  williams_r: boolean;
  cci: boolean;
  
  // Volume Indicators
  obv: boolean;
  
  // Volatility Indicators
  atr: boolean;
  
  // Trend Indicators
  adx: boolean;
  parabolicSar: boolean;
  
  // Support/Resistance
  supportResistance: boolean;
  fibonacciRetracements: boolean;
}

export default function TechnicalAnalysisStudioPage() {
  const [selectedSymbol, setSelectedSymbol] = useState('CMI');
  const [timeRange, setTimeRange] = useState<'1d' | '1w' | '1m' | '1y' | '5y' | '10y' | 'all'>('1d');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [showIndicatorPanel, setShowIndicatorPanel] = useState(true);
  
  const [indicators, setIndicators] = useState<TechnicalIndicators>({
    // Moving Averages
    sma20: true,
    sma30: false,
    sma50: true,
    sma60: false,
    sma90: false,
    sma200: false,
    ema12: false,
    ema26: false,
    
    // Bollinger Bands
    bollingerBands: false,
    
    // MACD
    macd: true,
    
    // Oscillators
    rsi: true,
    stochastic: false,
    williams_r: false,
    cci: false,
    
    // Volume Indicators
    obv: false,
    
    // Volatility Indicators
    atr: false,
    
    // Trend Indicators
    adx: false,
    parabolicSar: false,
    
    // Support/Resistance
    supportResistance: false,
    fibonacciRetracements: false
  });

  const symbols = [
    { value: 'CMI', label: 'Cummins Inc. (CMI)' },
    { value: 'AAPL', label: 'Apple Inc. (AAPL)' },
    { value: 'MSFT', label: 'Microsoft Corp. (MSFT)' },
    { value: 'GOOGL', label: 'Alphabet Inc. (GOOGL)' },
    { value: 'TSLA', label: 'Tesla Inc. (TSLA)' },
    { value: 'NVDA', label: 'NVIDIA Corp. (NVDA)' },
    { value: 'AMZN', label: 'Amazon.com Inc. (AMZN)' },
    { value: 'META', label: 'Meta Platforms Inc. (META)' }
  ];

  const timeRanges = [
    { value: '1d', label: '1 Day', icon: Clock },
    { value: '1w', label: '1 Week', icon: Calendar },
    { value: '1m', label: '1 Month', icon: Calendar },
    { value: '1y', label: '1 Year', icon: Calendar },
    { value: '5y', label: '5 Years', icon: TrendingUp },
    { value: '10y', label: '10 Years', icon: TrendingUp },
    { value: 'all', label: '20 Years (All Data)', icon: BarChart3 }
  ];

  const toggleIndicator = (key: keyof TechnicalIndicators) => {
    setIndicators(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const resetIndicators = () => {
    setIndicators({
      sma20: true,
      sma30: false,
      sma50: true,
      sma60: false,
      sma90: false,
      sma200: false,
      ema12: false,
      ema26: false,
      bollingerBands: false,
      macd: true,
      rsi: true,
      stochastic: false,
      williams_r: false,
      cci: false,
      obv: false,
      atr: false,
      adx: false,
      parabolicSar: false,
      supportResistance: false,
      fibonacciRetracements: false
    });
  };

  const indicatorGroups = [
    {
      title: 'Moving Averages',
      icon: TrendingUp,
      indicators: [
        { key: 'sma20', label: 'SMA 20', description: 'Simple Moving Average (20 periods)' },
        { key: 'sma30', label: 'SMA 30', description: 'Simple Moving Average (30 periods)' },
        { key: 'sma50', label: 'SMA 50', description: 'Simple Moving Average (50 periods)' },
        { key: 'sma60', label: 'SMA 60', description: 'Simple Moving Average (60 periods)' },
        { key: 'sma90', label: 'SMA 90', description: 'Simple Moving Average (90 periods)' },
        { key: 'sma200', label: 'SMA 200', description: 'Simple Moving Average (200 periods)' },
        { key: 'ema12', label: 'EMA 12', description: 'Exponential Moving Average (12 periods)' },
        { key: 'ema26', label: 'EMA 26', description: 'Exponential Moving Average (26 periods)' }
      ]
    },
    {
      title: 'Volatility Indicators',
      icon: Activity,
      indicators: [
        { key: 'bollingerBands', label: 'Bollinger Bands', description: 'Volatility bands around moving average' },
        { key: 'atr', label: 'ATR', description: 'Average True Range - measures volatility' }
      ]
    },
    {
      title: 'Momentum Oscillators',
      icon: Zap,
      indicators: [
        { key: 'macd', label: 'MACD', description: 'Moving Average Convergence Divergence' },
        { key: 'rsi', label: 'RSI', description: 'Relative Strength Index (14 periods)' },
        { key: 'stochastic', label: 'Stochastic', description: 'Stochastic Oscillator (%K, %D)' },
        { key: 'williams_r', label: 'Williams %R', description: 'Williams Percent Range' },
        { key: 'cci', label: 'CCI', description: 'Commodity Channel Index' }
      ]
    },
    {
      title: 'Volume Indicators',
      icon: BarChart2,
      indicators: [
        { key: 'obv', label: 'OBV', description: 'On-Balance Volume' }
      ]
    },
    {
      title: 'Trend Indicators',
      icon: LineChart,
      indicators: [
        { key: 'adx', label: 'ADX', description: 'Average Directional Index' },
        { key: 'parabolicSar', label: 'Parabolic SAR', description: 'Stop and Reverse indicator' }
      ]
    },
    {
      title: 'Support & Resistance',
      icon: Target,
      indicators: [
        { key: 'supportResistance', label: 'Support/Resistance', description: 'Key price levels' },
        { key: 'fibonacciRetracements', label: 'Fibonacci', description: 'Fibonacci retracement levels' }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Technical Analysis Studio</h1>
              <p className="text-gray-400">
                Professional-grade charting and technical analysis tools for comprehensive market analysis
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowIndicatorPanel(!showIndicatorPanel)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                  showIndicatorPanel
                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                    : 'bg-slate-700/50 text-gray-400 border border-slate-600/50 hover:bg-slate-600/50'
                }`}
              >
                {showIndicatorPanel ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                <span>Indicators Panel</span>
              </button>
              
              <button
                onClick={resetIndicators}
                className="px-4 py-2 bg-slate-700/50 text-gray-400 border border-slate-600/50 rounded-lg hover:bg-slate-600/50 transition-colors flex items-center space-x-2"
              >
                <Settings className="w-4 h-4" />
                <span>Reset</span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Indicator Controls Panel */}
          {showIndicatorPanel && (
            <div className="col-span-12 lg:col-span-3">
              <div className="bg-slate-900/50 backdrop-blur-md rounded-xl border border-slate-700/50 p-6 sticky top-6">
                <h2 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  Chart Controls
                </h2>
                
                {/* Asset Selection */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-300 mb-2">Asset Symbol</label>
                  <select
                    value={selectedSymbol}
                    onChange={(e) => setSelectedSymbol(e.target.value)}
                    className="w-full bg-slate-800/50 border border-slate-600/50 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  >
                    {symbols.map(symbol => (
                      <option key={symbol.value} value={symbol.value}>
                        {symbol.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Time Range Selection */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-300 mb-2">Time Range</label>
                  <div className="grid grid-cols-1 gap-2">
                    {timeRanges.map(range => {
                      const IconComponent = range.icon;
                      return (
                        <button
                          key={range.value}
                          onClick={() => setTimeRange(range.value as any)}
                          className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                            timeRange === range.value
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              : 'bg-slate-800/30 text-gray-400 border border-slate-600/30 hover:bg-slate-700/30'
                          }`}
                        >
                          <IconComponent className="w-4 h-4" />
                          <span>{range.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Technical Indicators */}
                <div className="space-y-4">
                  <h3 className="text-sm font-medium text-gray-300 flex items-center">
                    <Activity className="w-4 h-4 mr-2" />
                    Technical Indicators
                  </h3>
                  
                  {indicatorGroups.map(group => {
                    const IconComponent = group.icon;
                    return (
                      <div key={group.title} className="bg-slate-800/30 rounded-lg p-3">
                        <h4 className="text-xs font-medium text-gray-400 mb-2 flex items-center">
                          <IconComponent className="w-3 h-3 mr-1" />
                          {group.title}
                        </h4>
                        <div className="space-y-1">
                          {group.indicators.map(indicator => (
                            <label key={indicator.key} className="flex items-center space-x-2 cursor-pointer group">
                              <input
                                type="checkbox"
                                checked={indicators[indicator.key as keyof TechnicalIndicators]}
                                onChange={() => toggleIndicator(indicator.key as keyof TechnicalIndicators)}
                                className="w-3 h-3 text-blue-500 bg-slate-700 border-slate-600 rounded focus:ring-blue-500/50 focus:ring-2"
                              />
                              <div className="flex-1">
                                <span className="text-xs text-gray-300 group-hover:text-white transition-colors">
                                  {indicator.label}
                                </span>
                                <div className="text-xs text-gray-500 group-hover:text-gray-400 transition-colors">
                                  {indicator.description}
                                </div>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Main Chart Area */}
          <div className={showIndicatorPanel ? 'col-span-12 lg:col-span-9' : 'col-span-12'}>
            <HighchartsTechnicalChart
              symbol={selectedSymbol}
              timeRange={timeRange}
              selectedDate={timeRange === '1d' ? selectedDate : undefined}
              height={600}
              indicators={indicators}
              className="mb-6"
            />

            {/* Advanced Features Placeholder */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Stock Screener */}
              <div className="bg-slate-900/50 backdrop-blur-md rounded-xl border border-slate-700/50 p-6">
                <div className="flex items-center mb-4">
                  <Filter className="w-6 h-6 text-blue-400 mr-3" />
                  <h3 className="text-lg font-semibold text-white">Stock Screener</h3>
                </div>
                <p className="text-gray-400 text-sm mb-4">
                  Filter thousands of stocks based on technical criteria, volume surges, and indicator values.
                </p>
                <div className="space-y-2 text-xs text-gray-500">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-2"></div>
                    <span>Custom technical filters</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                    <span>Real-time screening</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full mr-2"></div>
                    <span>Pattern recognition</span>
                  </div>
                </div>
                <button className="w-full mt-4 px-4 py-2 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-lg hover:bg-blue-500/30 transition-colors text-sm font-medium">
                  Coming Soon
                </button>
              </div>

              {/* Backtesting Software */}
              <div className="bg-slate-900/50 backdrop-blur-md rounded-xl border border-slate-700/50 p-6">
                <div className="flex items-center mb-4">
                  <TestTube className="w-6 h-6 text-green-400 mr-3" />
                  <h3 className="text-lg font-semibold text-white">Backtesting Suite</h3>
                </div>
                <p className="text-gray-400 text-sm mb-4">
                  Test trading strategies with walk-forward testing, resampling, and Monte Carlo simulations.
                </p>
                <div className="space-y-2 text-xs text-gray-500">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-purple-400 rounded-full mr-2"></div>
                    <span>Walk-forward analysis</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-pink-400 rounded-full mr-2"></div>
                    <span>Monte Carlo simulations</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mr-2"></div>
                    <span>Performance analytics</span>
                  </div>
                </div>
                <button className="w-full mt-4 px-4 py-2 bg-green-500/20 text-green-400 border border-green-500/30 rounded-lg hover:bg-green-500/30 transition-colors text-sm font-medium">
                  Coming Soon
                </button>
              </div>

              {/* Paper Trading */}
              <div className="bg-slate-900/50 backdrop-blur-md rounded-xl border border-slate-700/50 p-6">
                <div className="flex items-center mb-4">
                  <Briefcase className="w-6 h-6 text-yellow-400 mr-3" />
                  <h3 className="text-lg font-semibold text-white">Paper Trading</h3>
                </div>
                <p className="text-gray-400 text-sm mb-4">
                  Practice trading with virtual money using real market data and research insights.
                </p>
                <div className="space-y-2 text-xs text-gray-500">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full mr-2"></div>
                    <span>Virtual portfolio</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-indigo-400 rounded-full mr-2"></div>
                    <span>Real-time execution</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-red-400 rounded-full mr-2"></div>
                    <span>Performance tracking</span>
                  </div>
                </div>
                <button className="w-full mt-4 px-4 py-2 bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 rounded-lg hover:bg-yellow-500/30 transition-colors text-sm font-medium">
                  Coming Soon
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}