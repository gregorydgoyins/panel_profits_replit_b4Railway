import React, { useState } from 'react';
import { Activity, TrendingUp, TrendingDown, Brain, AlertTriangle, Info, BarChart2, Users, Zap } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function FearGreedIndexPage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');

  // Calculate Fear & Greed Index from simulation data
  const marketSentiment = liveMetrics?.avgReturn || 0.025;
  const marketVolatility = liveMetrics?.marketVolatility || 0.25;
  const tradingVolume = liveMetrics?.totalTrades || 8547;
  const activeTradersRatio = (liveMetrics?.activeTradersCount || 2847) / (liveMetrics?.totalInvestors || 10000);

  // Fear & Greed calculation (0-100 scale)
  const calculateFearGreedIndex = () => {
    let index = 50; // Neutral starting point
    
    // Market sentiment component (40% weight)
    index += (marketSentiment * 100) * 0.4;
    
    // Volatility component (20% weight) - high volatility = fear
    index -= (marketVolatility * 100) * 0.2;
    
    // Trading activity component (25% weight) - high activity = greed
    index += (activeTradersRatio * 100 - 50) * 0.25;
    
    // Volume component (15% weight)
    const normalizedVolume = Math.min(tradingVolume / 10000, 1);
    index += (normalizedVolume * 50 - 25) * 0.15;
    
    return Math.max(0, Math.min(100, index));
  };

  const fearGreedIndex = calculateFearGreedIndex();

  const getFearGreedLevel = (index: number) => {
    if (index >= 75) return { level: 'Extreme Greed', color: 'text-red-400', bgColor: 'bg-red-900/30', borderColor: 'border-red-700/30' };
    if (index >= 55) return { level: 'Greed', color: 'text-orange-400', bgColor: 'bg-orange-900/30', borderColor: 'border-orange-700/30' };
    if (index >= 45) return { level: 'Neutral', color: 'text-yellow-400', bgColor: 'bg-yellow-900/30', borderColor: 'border-yellow-700/30' };
    if (index >= 25) return { level: 'Fear', color: 'text-blue-400', bgColor: 'bg-blue-900/30', borderColor: 'border-blue-700/30' };
    return { level: 'Extreme Fear', color: 'text-green-400', bgColor: 'bg-green-900/30', borderColor: 'border-green-700/30' };
  };

  const currentLevel = getFearGreedLevel(fearGreedIndex);

  const fearGreedComponents = [
    {
      name: 'Market Momentum',
      value: Math.max(0, Math.min(100, 50 + (marketSentiment * 100))),
      weight: 40,
      description: 'Price momentum and trend strength across all assets'
    },
    {
      name: 'Market Volatility',
      value: Math.max(0, Math.min(100, 100 - (marketVolatility * 100))),
      weight: 20,
      description: 'Price stability and predictability (inverted - low volatility = less fear)'
    },
    {
      name: 'Trading Activity',
      value: Math.max(0, Math.min(100, activeTradersRatio * 100)),
      weight: 25,
      description: 'Percentage of investors actively trading'
    },
    {
      name: 'Volume Strength',
      value: Math.max(0, Math.min(100, Math.min(tradingVolume / 10000, 1) * 100)),
      weight: 15,
      description: 'Trading volume relative to historical averages'
    }
  ];

  const historicalData = [
    { date: '1 week ago', index: 45, level: 'Neutral' },
    { date: '3 days ago', index: 38, level: 'Fear' },
    { date: 'Yesterday', index: 52, level: 'Greed' },
    { date: 'Today', index: fearGreedIndex, level: currentLevel.level }
  ];

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'Fear & Greed Index' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Activity className="h-8 w-8 text-orange-400" />
          <h1 className="text-3xl font-bold text-white">Comic Market Fear & Greed Index</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Brain className="h-5 w-5" />
          <span className="text-sm">AI-powered sentiment analysis</span>
        </div>
      </div>

      {/* Current Index Display */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Current Fear & Greed Index</h2>
            <div className="relative w-48 h-48 mx-auto mb-4">
              {/* Circular gauge */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#374151"
                  strokeWidth="8"
                  fill="transparent"
                  className="opacity-30"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke={currentLevel.color.replace('text-', '#')}
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - fearGreedIndex / 100)}`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-4xl font-bold ${currentLevel.color}`}>
                  {fearGreedIndex.toFixed(0)}
                </span>
                <span className={`text-sm font-medium ${currentLevel.color}`}>
                  {currentLevel.level}
                </span>
              </div>
            </div>
            <div className={`p-4 rounded-lg ${currentLevel.bgColor} border ${currentLevel.borderColor}`}>
              <p className="text-white font-medium mb-2">Market Sentiment: {currentLevel.level}</p>
              <p className="text-gray-300 text-sm">
                {fearGreedIndex >= 75 ? 'Investors are showing extreme optimism. Consider taking profits and preparing for potential corrections.' :
                 fearGreedIndex >= 55 ? 'Market sentiment is positive. Good time for selective buying but watch for overvaluation.' :
                 fearGreedIndex >= 45 ? 'Market is balanced. Normal trading conditions with mixed signals.' :
                 fearGreedIndex >= 25 ? 'Fear is driving the market. Potential buying opportunities for long-term investors.' :
                 'Extreme fear presents significant buying opportunities for patient investors with strong risk tolerance.'}
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">What is the Fear & Greed Index?</h3>
            <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <p className="text-gray-300 text-sm leading-relaxed mb-4">
                The Comic Market Fear & Greed Index measures the primary emotions driving the comic book investment market. 
                It analyzes multiple market indicators to determine whether investors are being driven by fear (selling pressure) 
                or greed (buying euphoria).
              </p>
              <div className="space-y-2">
                <h4 className="font-medium text-white">How it affects investors:</h4>
                <ul className="space-y-1 text-gray-300 text-sm">
                  <li>• <strong>Extreme Fear (0-25):</strong> Often signals buying opportunities as assets become oversold</li>
                  <li>• <strong>Fear (25-45):</strong> Cautious market conditions, good for selective value investing</li>
                  <li>• <strong>Neutral (45-55):</strong> Balanced market with normal trading patterns</li>
                  <li>• <strong>Greed (55-75):</strong> Optimistic market, watch for overvaluation risks</li>
                  <li>• <strong>Extreme Greed (75-100):</strong> Potential bubble conditions, consider profit-taking</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Index Components */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Index Components</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {fearGreedComponents.map((component, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-white">{component.name}</h3>
                <span className="text-sm text-gray-400">{component.weight}% weight</span>
              </div>
              <div className="flex items-center space-x-3 mb-2">
                <div className="flex-1 bg-slate-600 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-500 ${
                      component.value >= 60 ? 'bg-red-500' :
                      component.value >= 40 ? 'bg-yellow-500' :
                      'bg-green-500'
                    }`}
                    style={{ width: `${component.value}%` }}
                  />
                </div>
                <span className="text-white font-medium">{component.value.toFixed(0)}</span>
              </div>
              <p className="text-gray-400 text-xs">{component.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Historical Trend */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Recent Fear & Greed History</h2>
        <div className="space-y-3">
          {historicalData.map((data, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg border border-slate-600/50">
              <div className="flex items-center space-x-3">
                <span className="text-gray-400 text-sm">{data.date}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  data.index >= 75 ? 'bg-red-900/50 text-red-200' :
                  data.index >= 55 ? 'bg-orange-900/50 text-orange-200' :
                  data.index >= 45 ? 'bg-yellow-900/50 text-yellow-200' :
                  data.index >= 25 ? 'bg-blue-900/50 text-blue-200' :
                  'bg-green-900/50 text-green-200'
                }`}>
                  {data.level}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-white font-medium">{data.index.toFixed(0)}</span>
                {index > 0 && (
                  <div className="flex items-center">
                    {data.index > historicalData[index - 1].index ? (
                      <TrendingUp className="h-4  w-4 text-green-400" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-400" />
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trading Strategy Based on Fear & Greed */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Trading Strategies by Fear & Greed Level</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-green-900/30 p-4 rounded-lg border border-green-700/30">
            <h3 className="font-medium text-green-200 mb-2">Extreme Fear (0-25)</h3>
            <ul className="space-y-1 text-green-300 text-sm">
              <li>• Aggressive buying opportunities</li>
              <li>• Focus on blue-chip characters</li>
              <li>• Dollar-cost averaging strategy</li>
              <li>• Contrarian positioning</li>
            </ul>
          </div>
          
          <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-700/30">
            <h3 className="font-medium text-blue-200 mb-2">Fear (25-45)</h3>
            <ul className="space-y-1 text-blue-300 text-sm">
              <li>• Selective value buying</li>
              <li>• Research-driven decisions</li>
              <li>• Avoid momentum trades</li>
              <li>• Build watchlists</li>
            </ul>
          </div>
          
          <div className="bg-yellow-900/30 p-4 rounded-lg border border-yellow-700/30">
            <h3 className="font-medium text-yellow-200 mb-2">Neutral (45-55)</h3>
            <ul className="space-y-1 text-yellow-300 text-sm">
              <li>• Balanced approach</li>
              <li>• Normal trading patterns</li>
              <li>• Portfolio rebalancing</li>
              <li>• Mixed strategies work</li>
            </ul>
          </div>
          
          <div className="bg-orange-900/30 p-4 rounded-lg border border-orange-700/30">
            <h3 className="font-medium text-orange-200 mb-2">Greed (55-75)</h3>
            <ul className="space-y-1 text-orange-300 text-sm">
              <li>• Cautious profit-taking</li>
              <li>• Avoid FOMO trades</li>
              <li>• Tighten stop-losses</li>
              <li>• Research fundamentals</li>
            </ul>
          </div>
          
          <div className="bg-red-900/30 p-4 rounded-lg border border-red-700/30">
            <h3 className="font-medium text-red-200 mb-2">Extreme Greed (75-100)</h3>
            <ul className="space-y-1 text-red-300 text-sm">
              <li>• Aggressive profit-taking</li>
              <li>• Reduce position sizes</li>
              <li>• Prepare for correction</li>
              <li>• Avoid new positions</li>
            </ul>
          </div>
          
          <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
            <h3 className="font-medium text-white mb-2">Current Recommendation</h3>
            <div className={`p-3 rounded-lg ${currentLevel.bgColor} border ${currentLevel.borderColor}`}>
              <p className={`font-medium ${currentLevel.color} mb-1`}>
                {currentLevel.level} Market
              </p>
              <p className="text-gray-300 text-sm">
                {fearGreedIndex >= 75 ? 'Consider reducing exposure and taking profits. Market may be overheated.' :
                 fearGreedIndex >= 55 ? 'Maintain current positions but be selective with new investments.' :
                 fearGreedIndex >= 45 ? 'Normal market conditions. Standard trading strategies apply.' :
                 fearGreedIndex >= 25 ? 'Good buying opportunities emerging. Research quality assets.' :
                 'Excellent buying opportunities for long-term investors. Market is oversold.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Market Psychology Education */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Understanding Market Psychology</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Fear-Driven Behaviors</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Panic Selling</p>
                  <p className="text-gray-300 text-sm">Investors sell assets at any price to avoid further losses</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Analysis Paralysis</p>
                  <p className="text-gray-300 text-sm">Over-analyzing leads to missed opportunities</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Herding Behavior</p>
                  <p className="text-gray-300 text-sm">Following the crowd instead of independent analysis</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Greed-Driven Behaviors</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Zap className="h-5 w-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">FOMO Trading</p>
                  <p className="text-gray-300 text-sm">Fear of missing out leads to chasing price spikes</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Zap className="h-5 w-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Overleveraging</p>
                  <p className="text-gray-300 text-sm">Taking excessive risk for higher returns</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Zap className="h-5 w-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-white font-medium">Ignoring Risk</p>
                  <p className="text-gray-300 text-sm">Dismissing warning signs during bull markets</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contrarian Investment Philosophy */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Contrarian Investment Strategy</h2>
            <p className="text-white/90 mb-4">
              "Be fearful when others are greedy, and greedy when others are fearful." - Warren Buffett
            </p>
            <p className="text-white/80 text-sm">
              The Fear & Greed Index helps identify when market sentiment has reached extremes, 
              often signaling the best times to take contrarian positions for long-term success.
            </p>
          </div>
          <div className="hidden md:block">
            <Brain className="h-24 w-24 text-white/20" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default FearGreedIndexPage;