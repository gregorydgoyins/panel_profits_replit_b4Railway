import React, { useState } from 'react';
import { Activity, TrendingUp, TrendingDown, BarChart2, Clock, Users, Info, Calendar } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function VolumeAnalysisPage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');

  const totalVolume = (liveMetrics?.totalTrades || 8547) * 25000; // Average trade size
  const volumeChange = 15.3; // Mock daily change
  const avgTradeSize = 25000;

  const volumeBreakdown = [
    { category: 'Character Stocks', volume: totalVolume * 0.42, percentage: 42, trades: 3589, avgSize: 28500 },
    { category: 'Key Comics', volume: totalVolume * 0.28, percentage: 28, trades: 1247, avgSize: 45200 },
    { category: 'Creator Stocks', volume: totalVolume * 0.18, percentage: 18, trades: 1589, avgSize: 22800 },
    { category: 'Publisher Bonds', volume: totalVolume * 0.08, percentage: 8, trades: 456, avgSize: 35200 },
    { category: 'Funds & ETFs', volume: totalVolume * 0.04, percentage: 4, trades: 666, avgSize: 12100 }
  ];

  const hourlyVolume = [
    { hour: '09:30', volume: 45200, change: 12.5 },
    { hour: '10:00', volume: 52800, change: 8.2 },
    { hour: '11:00', volume: 38900, change: -5.1 },
    { hour: '12:00', volume: 28500, change: -12.8 },
    { hour: '13:00', volume: 31200, change: 2.4 },
    { hour: '14:00', volume: 47600, change: 18.9 },
    { hour: '15:00', volume: 55800, change: 22.1 },
    { hour: '15:30', volume: 68900, change: 35.7 }
  ];

  const topVolumeAssets = [
    { symbol: 'ASM300', name: 'Amazing Spider-Man #300', volume: 125000, change: 8.5, reason: 'Venom movie news' },
    { symbol: 'BATM', name: 'Batman', volume: 98000, change: 6.2, reason: 'Movie sequel announcement' },
    { symbol: 'SPDR', name: 'Spider-Man', volume: 87500, change: 5.3, reason: 'Spider-Man 4 confirmation' },
    { symbol: 'TMFS', name: 'Todd McFarlane', volume: 76200, change: 5.8, reason: 'Spawn Universe expansion' },
    { symbol: 'AF15', name: 'Amazing Fantasy #15', volume: 12500, change: 5.57, reason: 'Auction record breaking' }
  ];

  const institutionalActivity = [
    { institution: 'Heritage Investment Fund', activity: 'Large ASM300 accumulation', volume: 45000, impact: 'Bullish' },
    { institution: 'Comic Capital Partners', activity: 'DC character diversification', volume: 38000, impact: 'Neutral' },
    { institution: 'Golden Age Preservation', activity: 'Vintage comic acquisition', volume: 32000, impact: 'Bullish' },
    { institution: 'Creator Bond Fund', activity: 'McFarlane bond purchases', volume: 28000, impact: 'Bullish' }
  ];

  const formatVolume = (value: number) => {
    if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B CC`;
    if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M CC`;
    if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K CC`;
    return `${value.toFixed(2)} CC`;
  };

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'Volume Analysis' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Activity className="h-8 w-8 text-blue-400" />
          <h1 className="text-3xl font-bold text-white">Trading Volume Analysis</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <BarChart2 className="h-5 w-5" />
          <span className="text-sm">Real-time volume tracking</span>
        </div>
      </div>

      {/* Total Volume Overview */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-4">Today's Trading Volume</h2>
            <div className="flex items-center space-x-4 mb-4">
              <div>
                <p className="text-4xl font-bold text-white">{formatVolume(totalVolume)}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <span className="text-green-400 font-semibold">
                    +{volumeChange}% vs yesterday
                  </span>
                </div>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Trading volume represents the total value of all comic assets traded today. High volume indicates strong investor interest 
              and can signal significant price movements. Today's elevated volume is driven by earnings announcements, 
              movie confirmations, and increased institutional activity across multiple asset categories.
            </p>
          </div>
          
          <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
            <h3 className="font-medium text-white mb-3">Volume Metrics</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Trades:</span>
                <span className="text-white">{(liveMetrics?.totalTrades || 8547).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Trade Size:</span>
                <span className="text-white">CC {avgTradeSize.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Active Traders:</span>
                <span className="text-white">{(liveMetrics?.activeTradersCount || 2847).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Market Participation:</span>
                <span className="text-white">{(((liveMetrics?.activeTradersCount || 2847) / (liveMetrics?.totalInvestors || 10000)) * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Volume by Category */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Volume by Asset Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {volumeBreakdown.map((category, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 hover:shadow-lg transition-all">
              <h3 className="font-medium text-white mb-3">{category.category}</h3>
              <p className="text-2xl font-bold text-white mb-2">{formatVolume(category.volume)}</p>
              <div className="w-full bg-slate-600 rounded-full h-2 mb-3">
                <div 
                  className="bg-blue-500 h-2 rounded-full"
                  style={{ width: `${category.percentage}%` }}
                />
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-400">Trades</p>
                  <p className="text-white">{category.trades.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-400">Avg Size</p>
                  <p className="text-white">CC {category.avgSize.toLocaleString()}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Hourly Volume Pattern */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Intraday Volume Pattern</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {hourlyVolume.map((data, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">{data.hour}</span>
                <span className={`text-sm font-medium ${data.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {data.change > 0 ? '+' : ''}{data.change}%
                </span>
              </div>
              <p className="text-white font-bold">{formatVolume(data.volume)}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-indigo-900/30 p-4 rounded-lg border border-indigo-700/30">
          <p className="text-indigo-200 text-sm">
            <strong>Volume Patterns:</strong> Market open and close show highest activity. Lunch hour (12:00) typically sees reduced volume. 
            Power hour (15:00-16:00) often shows surge as institutional traders position for overnight holds.
          </p>
        </div>
      </div>

      {/* Top Volume Assets */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Highest Volume Assets Today</h2>
        <div className="space-y-4">
          {topVolumeAssets.map((asset, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 hover:bg-slate-700 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-lg font-bold text-indigo-400">#{index + 1}</span>
                  <div>
                    <h3 className="font-semibold text-white">{asset.name}</h3>
                    <p className="text-sm text-gray-400">{asset.symbol} • {asset.reason}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">{formatVolume(asset.volume)}</p>
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-4 w-4 text-green-400" />
                    <span className="text-green-400 font-medium">+{asset.change}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Institutional Activity */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Institutional Trading Activity</h2>
        <div className="space-y-4">
          {institutionalActivity.map((activity, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-white">{activity.institution}</h3>
                  <p className="text-gray-300 text-sm">{activity.activity}</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-medium">{formatVolume(activity.volume)}</p>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    activity.impact === 'Bullish' ? 'bg-green-900/50 text-green-200' :
                    activity.impact === 'Bearish' ? 'bg-red-900/50 text-red-200' :
                    'bg-yellow-900/50 text-yellow-200'
                  }`}>
                    {activity.impact}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default VolumeAnalysisPage;