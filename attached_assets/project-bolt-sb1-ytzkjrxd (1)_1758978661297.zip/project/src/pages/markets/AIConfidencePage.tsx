import React, { useState } from 'react';
import { Brain, TrendingUp, TrendingDown, Target, BarChart2, Zap, Info, Activity } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function AIConfidencePage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');

  const aiConfidence = liveMetrics?.aiConfidence || 87.5;
  const confidenceChange = 2.3; // Mock daily change

  const confidenceComponents = [
    {
      name: 'Prediction Accuracy',
      score: 89.2,
      weight: 35,
      description: 'Historical accuracy of AI price predictions over various timeframes',
      trend: 'improving'
    },
    {
      name: 'Pattern Recognition',
      score: 92.1,
      weight: 25,
      description: 'AI ability to identify market patterns and correlations',
      trend: 'stable'
    },
    {
      name: 'Sentiment Analysis',
      score: 85.7,
      weight: 20,
      description: 'Accuracy in analyzing news sentiment and market impact',
      trend: 'improving'
    },
    {
      name: 'Risk Assessment',
      score: 83.4,
      weight: 15,
      description: 'Portfolio risk modeling and volatility predictions',
      trend: 'stable'
    },
    {
      name: 'Anomaly Detection',
      score: 91.8,
      weight: 5,
      description: 'Identifying unusual market conditions and events',
      trend: 'improving'
    }
  ];

  const recentPredictions = [
    {
      asset: 'ASM300',
      prediction: 'Price increase 8-12% within 2 weeks',
      confidence: 92,
      status: 'Ongoing',
      reason: 'Venom movie sequel confirmation pattern',
      timeframe: '2 weeks',
      currentAccuracy: 'On track (+8.5% so far)'
    },
    {
      asset: 'BATM',
      prediction: 'Sustained upward momentum',
      confidence: 88,
      status: 'Confirmed',
      reason: 'Batman sequel announcement correlation',
      timeframe: '1 month',
      currentAccuracy: 'Achieved (+6.2%)'
    },
    {
      asset: 'TMFS',
      prediction: 'Creator stock surge on announcement',
      confidence: 85,
      status: 'Confirmed',
      reason: 'Historical pattern analysis',
      timeframe: '1 week',
      currentAccuracy: 'Exceeded (+5.8%)'
    },
    {
      asset: 'DCCP',
      prediction: 'Temporary volatility from restructuring',
      confidence: 79,
      status: 'Ongoing',
      reason: 'Corporate change impact modeling',
      timeframe: '2-3 weeks',
      currentAccuracy: 'Tracking as expected'
    }
  ];

  const modelPerformance = [
    { model: 'Character Price Predictor', accuracy: 87.3, trades: 12547, profitable: 89.2 },
    { model: 'News Impact Analyzer', accuracy: 82.1, trades: 8932, profitable: 76.8 },
    { model: 'Volatility Forecaster', accuracy: 85.7, trades: 6743, profitable: 83.4 },
    { model: 'Pattern Recognition Engine', accuracy: 91.2, trades: 15234, profitable: 92.1 },
    { model: 'Sentiment Correlation Model', accuracy: 78.9, trades: 5689, profitable: 74.3 }
  ];

  const getConfidenceLevel = (score: number) => {
    if (score >= 90) return { level: 'Very High', color: 'text-green-400', bgColor: 'bg-green-900/30' };
    if (score >= 80) return { level: 'High', color: 'text-blue-400', bgColor: 'bg-blue-900/30' };
    if (score >= 70) return { level: 'Moderate', color: 'text-yellow-400', bgColor: 'bg-yellow-900/30' };
    if (score >= 60) return { level: 'Low', color: 'text-orange-400', bgColor: 'bg-orange-900/30' };
    return { level: 'Very Low', color: 'text-red-400', bgColor: 'bg-red-900/30' };
  };

  const overallLevel = getConfidenceLevel(aiConfidence);

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'AI Confidence' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Brain className="h-8 w-8 text-purple-400" />
          <h1 className="text-3xl font-bold text-white">AI Market Confidence Analysis</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Zap className="h-5 w-5" />
          <span className="text-sm">Real-time AI monitoring</span>
        </div>
      </div>

      {/* Overall AI Confidence */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Current AI Confidence Level</h2>
            <div className="relative w-48 h-48 mx-auto mb-4">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#374151"
                  strokeWidth="8"
                  fill="transparent"
                  className="opacity-30"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#8B5CF6"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - aiConfidence / 100)}`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold text-purple-400">
                  {aiConfidence.toFixed(1)}%
                </span>
                <span className="text-sm font-medium text-purple-300">
                  {overallLevel.level}
                </span>
              </div>
            </div>
            <div className={`p-4 rounded-lg ${overallLevel.bgColor} border border-purple-700/30`}>
              <p className="text-white font-medium mb-2">AI Confidence: {overallLevel.level}</p>
              <p className="text-gray-300 text-sm">
                {aiConfidence >= 90 ? 'AI models are performing exceptionally well with high prediction accuracy.' :
                 aiConfidence >= 80 ? 'AI models are reliable with strong predictive performance.' :
                 aiConfidence >= 70 ? 'AI models are moderately confident with acceptable accuracy.' :
                 'AI models are showing lower confidence. Use predictions with caution.'}
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">What is AI Confidence?</h3>
            <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <p className="text-gray-300 text-sm leading-relaxed mb-4">
                AI Confidence measures the reliability and accuracy of our machine learning models in predicting market movements, 
                analyzing sentiment, and identifying trading opportunities. Higher confidence indicates more reliable AI insights.
              </p>
              <div className="space-y-2">
                <h4 className="font-medium text-white">Confidence Levels:</h4>
                <ul className="space-y-1 text-gray-300 text-sm">
                  <li>• <strong>Very High (90-100%):</strong> Exceptional model performance, highly reliable predictions</li>
                  <li>• <strong>High (80-89%):</strong> Strong model performance, reliable for decision making</li>
                  <li>• <strong>Moderate (70-79%):</strong> Acceptable performance, use with additional analysis</li>
                  <li>• <strong>Low (60-69%):</strong> Weak performance, require manual verification</li>
                  <li>• <strong>Very Low (0-59%):</strong> Poor performance, avoid automated decisions</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Model Components */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">AI Model Performance Breakdown</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {confidenceComponents.map((component, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-white">{component.name}</h3>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-400">{component.weight}% weight</span>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    component.trend === 'improving' ? 'bg-green-900/50 text-green-200' :
                    component.trend === 'stable' ? 'bg-blue-900/50 text-blue-200' :
                    'bg-yellow-900/50 text-yellow-200'
                  }`}>
                    {component.trend}
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-3 mb-2">
                <div className="flex-1 bg-slate-600 rounded-full h-2">
                  <div 
                    className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${component.score}%` }}
                  />
                </div>
                <span className="text-white font-medium">{component.score.toFixed(1)}%</span>
              </div>
              <p className="text-gray-400 text-xs">{component.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Recent AI Predictions */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Recent AI Predictions & Performance</h2>
        <div className="space-y-4">
          {recentPredictions.map((prediction, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-white">{prediction.asset}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      prediction.status === 'Confirmed' ? 'bg-green-900/50 text-green-200' :
                      prediction.status === 'Ongoing' ? 'bg-blue-900/50 text-blue-200' :
                      'bg-yellow-900/50 text-yellow-200'
                    }`}>
                      {prediction.status}
                    </span>
                    <span className="text-purple-400  text-sm">{prediction.confidence}% confidence</span>
                  </div>
                  <p className="text-gray-300 text-sm mb-2">{prediction.prediction}</p>
                  <p className="text-gray-400 text-xs mb-1">Reasoning: {prediction.reason}</p>
                  <p className="text-gray-400 text-xs">Timeframe: {prediction.timeframe}</p>
                </div>
                <div className="text-right">
                  <p className={`font-medium ${
                    prediction.status === 'Confirmed' ? 'text-green-400' :
                    prediction.status === 'Ongoing' ? 'text-blue-400' :
                    'text-yellow-400'
                  }`}>
                    {prediction.currentAccuracy}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Model Performance Details */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Individual Model Performance</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-700/50">
            <thead>
              <tr className="bg-slate-700/30">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Model</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Accuracy</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Trades Analyzed</th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-400 uppercase tracking-wider">Profitable Rate</th>
                <th className="px-4 py-3 text-center text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {modelPerformance.map((model, index) => (
                <tr key={index} className="hover:bg-slate-700/30">
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-white">{model.model}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <span className={`font-semibold ${
                      model.accuracy >= 85 ? 'text-green-400' :
                      model.accuracy >= 75 ? 'text-blue-400' :
                      'text-yellow-400'
                    }`}>
                      {model.accuracy.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-right text-gray-300">{model.trades.toLocaleString()}</td>
                  <td className="px-4 py-4 whitespace-nowrap text-right">
                    <span className={`font-semibold ${
                      model.profitable >= 85 ? 'text-green-400' :
                      model.profitable >= 75 ? 'text-blue-400' :
                      'text-yellow-400'
                    }`}>
                      {model.profitable.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      model.accuracy >= 85 ? 'bg-green-900/50 text-green-200' :
                      model.accuracy >= 75 ? 'bg-blue-900/50 text-blue-200' :
                      'bg-yellow-900/50 text-yellow-200'
                    }`}>
                      {model.accuracy >= 85 ? 'Excellent' : model.accuracy >= 75 ? 'Good' : 'Fair'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Insights & Recommendations */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Current AI Market Insights</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">High Confidence Signals</h3>
            <div className="space-y-3">
              <div className="bg-green-900/30 p-4 rounded-lg border border-green-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <h4 className="font-medium text-green-200">Spider-Man Universe Expansion</h4>
                </div>
                <p className="text-green-300 text-sm">92% confidence in continued SPDR and ASM300 appreciation over next 30 days</p>
              </div>
              
              <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <Target className="h-5 w-5 text-blue-400" />
                  <h4 className="font-medium text-blue-200">Creator Bond Strength</h4>
                </div>
                <p className="text-blue-300 text-sm">88% confidence in creator bond outperformance vs character stocks</p>
              </div>
              
              <div className="bg-purple-900/30 p-4 rounded-lg border border-purple-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <Brain className="h-5 w-5 text-purple-400" />
                  <h4 className="font-medium text-purple-200">Pattern Recognition</h4>
                </div>
                <p className="text-purple-300 text-sm">91% confidence in identifying optimal entry/exit points</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Model Limitations</h3>
            <div className="space-y-3">
              <div className="bg-yellow-900/30 p-4 rounded-lg border border-yellow-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <Info className="h-5 w-5 text-yellow-400" />
                  <h4 className="font-medium text-yellow-200">Black Swan Events</h4>
                </div>
                <p className="text-yellow-300 text-sm">AI cannot predict unprecedented events or major industry disruptions</p>
              </div>
              
              <div className="bg-orange-900/30 p-4 rounded-lg border border-orange-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <Activity className="h-5 w-5 text-orange-400" />
                  <h4 className="font-medium text-orange-200">Market Manipulation</h4>
                </div>
                <p className="text-orange-300 text-sm">Models may be less effective during coordinated manipulation attempts</p>
              </div>
              
              <div className="bg-red-900/30 p-4 rounded-lg border border-red-700/30">
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingDown className="h-5 w-5 text-red-400" />
                  <h4 className="font-medium text-red-200">Extreme Volatility</h4>
                </div>
                <p className="text-red-300 text-sm">Performance degrades during extreme market stress conditions</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* How to Use AI Insights */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">How to Use AI Insights</h2>
            <p className="text-white/90 mb-4">
              AI confidence levels help you understand when to rely on automated insights versus manual analysis.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-white/80 text-sm">
              <div>
                <strong>High Confidence (80%+):</strong> Safe to use AI recommendations for position sizing and entry/exit timing
              </div>
              <div>
                <strong>Low Confidence (70%-):</strong> Use AI as supplementary analysis alongside fundamental research
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <Brain className="h-24 w-24 text-white/20" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default AIConfidencePage;