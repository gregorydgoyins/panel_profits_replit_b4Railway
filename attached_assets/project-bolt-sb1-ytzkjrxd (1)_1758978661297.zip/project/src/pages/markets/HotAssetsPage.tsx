import React, { useState } from 'react';
import { Star, TrendingUp, TrendingDown, Flame, Activity, Clock, Users, Target } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function HotAssetsPage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');

  const hotAssetsCount = liveMetrics?.hotAssetsCount || 87;
  const totalAssets = liveMetrics?.totalAssetsCount || 291;
  const hotPercentage = (hotAssetsCount / totalAssets) * 100;

  const hotAssets = [
    {
      symbol: 'ASM300',
      name: 'Amazing Spider-Man #300',
      type: 'comic',
      price: 2650,
      change: 425,
      percentChange: 8.5,
      volume: 185000,
      volumeChange: 340,
      reason: 'Venom movie sequel confirmed',
      heatScore: 98,
      socialMentions: 15420,
      newsArticles: 12
    },
    {
      symbol: 'BATM',
      name: 'Batman',
      type: 'character',
      price: 4462,
      change: 262,
      percentChange: 6.2,
      volume: 156000,
      volumeChange: 280,
      reason: 'The Batman Part II production start',
      heatScore: 95,
      socialMentions: 18750,
      newsArticles: 8
    },
    {
      symbol: 'TMFS',
      name: 'Todd McFarlane',
      type: 'creator',
      price: 1958,
      change: 113.64,
      percentChange: 5.8,
      volume: 89000,
      volumeChange: 420,
      reason: 'Spawn Universe TV deal announced',
      heatScore: 92,
      socialMentions: 9850,
      newsArticles: 6
    },
    {
      symbol: 'SPDR',
      name: 'Spider-Man',
      type: 'character',
      price: 3686,
      change: 195.36,
      percentChange: 5.3,
      volume: 142000,
      volumeChange: 290,
      reason: 'Spider-Man 4 casting rumors',
      heatScore: 89,
      socialMentions: 22100,
      newsArticles: 15
    },
    {
      symbol: 'WNDR',
      name: 'Wonder Woman',
      type: 'character',
      price: 3986,
      change: 195.22,
      percentChange: 4.9,
      volume: 98000,
      volumeChange: 180,
      reason: 'Wonder Woman 3 director confirmed',
      heatScore: 86,
      socialMentions: 11200,
      newsArticles: 7
    },
    {
      symbol: 'JLES',
      name: 'Jim Lee',
      type: 'creator',
      price: 3200,
      change: 169.60,
      percentChange: 5.3,
      volume: 76000,
      volumeChange: 220,
      reason: 'DC creative restructuring leadership',
      heatScore: 83,
      socialMentions: 6750,
      newsArticles: 4
    },
    {
      symbol: 'AF15',
      name: 'Amazing Fantasy #15',
      type: 'comic',
      price: 1800000,
      change: 100260,
      percentChange: 5.57,
      volume: 8500,
      volumeChange: 450,
      reason: 'Record auction sale reported',
      heatScore: 91,
      socialMentions: 8900,
      newsArticles: 9
    },
    {
      symbol: 'MRVL',
      name: 'Marvel Entertainment',
      type: 'publisher',
      price: 4850,
      change: 150.35,
      percentChange: 3.1,
      volume: 125000,
      volumeChange: 160,
      reason: 'Q4 earnings beat expectations',
      heatScore: 88,
      socialMentions: 12400,
      newsArticles: 11
    }
  ];

  const emergingHotAssets = [
    { symbol: 'SAGA1', name: 'Saga #1', heatScore: 78, trend: 'Rising', reason: 'Volume 11 announcement' },
    { symbol: 'INVN', name: 'Invincible', heatScore: 75, trend: 'Rising', reason: 'Season 2 trailer release' },
    { symbol: 'WALK', name: 'Walking Dead', heatScore: 72, trend: 'Rising', reason: 'Spin-off series renewal' },
    { symbol: 'DOOM', name: 'Doctor Doom', heatScore: 69, trend: 'Rising', reason: 'MCU appearance rumors' }
  ];

  const coolingAssets = [
    { symbol: 'LEXL', name: 'Lex Luthor', heatScore: 45, trend: 'Cooling', reason: 'Superman reboot uncertainty' },
    { symbol: 'ARTS', name: 'Stanley Lau', heatScore: 42, trend: 'Cooling', reason: 'Contract renewal concerns' },
    { symbol: 'BMBS', name: 'Brian Bendis', heatScore: 38, trend: 'Cooling', reason: 'Project delays reported' }
  ];

  const heatFactors = [
    { factor: 'Price Movement', weight: 30, description: 'Magnitude and speed of price changes' },
    { factor: 'Volume Surge', weight: 25, description: 'Trading volume vs historical averages' },
    { factor: 'Social Sentiment', weight: 20, description: 'Social media mentions and engagement' },
    { factor: 'News Coverage', weight: 15, description: 'Number and impact of news articles' },
    { factor: 'Institutional Interest', weight: 10, description: 'Large trader and fund activity' }
  ];

  const filteredAssets = selectedCategory === 'all' ? hotAssets : hotAssets.filter(asset => asset.type === selectedCategory);

  const getHeatColor = (score: number) => {
    if (score >= 90) return 'text-red-400';
    if (score >= 80) return 'text-orange-400';
    if (score >= 70) return 'text-yellow-400';
    if (score >= 60) return 'text-blue-400';
    return 'text-gray-400';
  };

  const getHeatBg = (score: number) => {
    if (score >= 90) return 'bg-red-900/30 border-red-700/30';
    if (score >= 80) return 'bg-orange-900/30 border-orange-700/30';
    if (score >= 70) return 'bg-yellow-900/30 border-yellow-700/30';
    if (score >= 60) return 'bg-blue-900/30 border-blue-700/30';
    return 'bg-gray-900/30 border-gray-700/30';
  };

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'Hot Assets' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Flame className="h-8 w-8 text-red-400" />
          <h1 className="text-3xl font-bold text-white">Hot Assets Tracker</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Activity className="h-5 w-5" />
          <span className="text-sm">Real-time heat scoring</span>
        </div>
      </div>

      {/* Hot Assets Overview */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-4">Market Heat Analysis</h2>
            <div className="flex items-center space-x-4 mb-4">
              <div>
                <p className="text-4xl font-bold text-red-400">{hotAssetsCount}</p>
                <p className="text-gray-400">hot assets out of {totalAssets} total</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Flame className="h-5 w-5 text-red-400" />
                  <span className="text-red-400 font-semibold">
                    {hotPercentage.toFixed(1)}% of market is heating up
                  </span>
                </div>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Hot assets are identified using our proprietary heat scoring algorithm that analyzes price movement, 
              volume surges, social sentiment, news coverage, and institutional interest. Assets with scores above 70 
              are considered "hot" and warrant close attention from traders and investors.
            </p>
          </div>
          
          <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
            <h3 className="font-medium text-white mb-3">Heat Distribution</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Extreme Heat (90+):</span>
                <span className="text-red-400 font-medium">12 assets</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">High Heat (80-89):</span>
                <span className="text-orange-400 font-medium">28 assets</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Moderate Heat (70-79):</span>
                <span className="text-yellow-400 font-medium">47 assets</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Cooling (60-69):</span>
                <span className="text-blue-400 font-medium">89 assets</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-4 shadow-xl">
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center space-x-2">
            <span className="text-gray-400 text-sm">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-500 px-3 py-2"
            >
              <option value="all">All Assets</option>
              <option value="character">Characters</option>
              <option value="comic">Comics</option>
              <option value="creator">Creators</option>
              <option value="publisher">Publishers</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-gray-400 text-sm">Timeframe:</span>
            <select
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
              className="bg-slate-700/50 border border-slate-600/50 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-500 px-3 py-2"
            >
              <option value="1h">1 Hour</option>
              <option value="1d">1 Day</option>
              <option value="1w">1 Week</option>
              <option value="1m">1 Month</option>
            </select>
          </div>
          
          <div className="ml-auto text-sm text-gray-400">
            {filteredAssets.length} hot assets found
          </div>
        </div>
      </div>

      {/* Hot Assets List */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Hottest Assets Right Now</h2>
        <div className="space-y-4">
          {filteredAssets.map((asset, index) => (
            <div key={index} className={`p-4 rounded-lg border hover:shadow-lg transition-all ${getHeatBg(asset.heatScore)}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Flame className={`h-6 w-6 ${getHeatColor(asset.heatScore)}`} />
                    <span className={`text-2xl font-bold ${getHeatColor(asset.heatScore)}`}>
                      {asset.heatScore}
                    </span>
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-3">
                      <h3 className="font-semibold text-white text-lg">{asset.name}</h3>
                      <span className="px-2 py-1 bg-slate-700/50 text-gray-300 rounded text-xs uppercase">
                        {asset.type}
                      </span>
                      <span className="text-gray-400 text-sm">{asset.symbol}</span>
                    </div>
                    <p className="text-gray-300 text-sm mt-1">{asset.reason}</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center space-x-4">
                    <div>
                      <p className="text-white font-bold">
                        CC {asset.price >= 1000000 ? 
                          `${(asset.price / 1000000).toFixed(2)}M` : 
                          asset.price.toLocaleString()
                        }
                      </p>
                      <div className="flex items-center space-x-1">
                        <TrendingUp className="h-4 w-4 text-green-400" />
                        <span className="text-green-400 font-medium">
                          +{asset.percentChange}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-400">
                      <p>Volume: {(asset.volume / 1000).toFixed(0)}K CC</p>
                      <p>+{asset.volumeChange}% vs avg</p>
                    </div>
                    
                    <div className="text-sm text-gray-400">
                      <p>{asset.socialMentions.toLocaleString()} mentions</p>
                      <p>{asset.newsArticles} news articles</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Emerging and Cooling Assets */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
          <h2 className="text-xl font-bold text-white mb-6">Emerging Hot Assets</h2>
          <div className="space-y-3">
            {emergingHotAssets.map((asset, index) => (
              <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-white">{asset.name}</h3>
                    <p className="text-gray-400 text-sm">{asset.reason}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <span className="text-yellow-400 font-bold">{asset.heatScore}</span>
                      <TrendingUp className="h-4 w-4 text-green-400" />
                    </div>
                    <span className="text-green-400 text-sm">{asset.trend}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
          <h2 className="text-xl font-bold text-white mb-6">Cooling Assets</h2>
          <div className="space-y-3">
            {coolingAssets.map((asset, index) => (
              <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-white">{asset.name}</h3>
                    <p className="text-gray-400 text-sm">{asset.reason}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <span className="text-blue-400 font-bold">{asset.heatScore}</span>
                      <TrendingDown className="h-4 w-4 text-red-400" />
                    </div>
                    <span className="text-blue-400 text-sm">{asset.trend}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Heat Scoring Methodology */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Heat Scoring Methodology</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {heatFactors.map((factor, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-white">{factor.factor}</h3>
                <span className="text-red-400 font-bold">{factor.weight}%</span>
              </div>
              <p className="text-gray-300 text-sm">{factor.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-red-900/30 p-4 rounded-lg border border-red-700/30">
          <p className="text-red-200 text-sm">
            <strong>Heat Score Formula:</strong> Our proprietary algorithm combines these factors with real-time weighting 
            adjustments based on market conditions. Scores are updated every 5 minutes during market hours.
          </p>
        </div>
      </div>
    </div>
  );
}

export default HotAssetsPage;