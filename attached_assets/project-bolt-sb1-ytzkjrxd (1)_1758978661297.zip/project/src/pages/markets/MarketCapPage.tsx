import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Calendar, Building2, Users, BarChart2, Info, Star, Activity, Globe } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';
import { useNewsData } from '../../hooks/useNewsData';

export function MarketCapPage() {
  const { liveMetrics } = useSimulationStore();
  const { data: news } = useNewsData({ limit: 5 });
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');

  const totalMarketCap = liveMetrics?.totalMarketCap || 125000000000;
  const marketCapChange = 2.3; // Mock daily change
  const marketCapChangeValue = totalMarketCap * (marketCapChange / 100);

  const formatMarketCap = (value: number) => {
    if (value >= 1e12) return `${(value / 1e12).toFixed(2)}T CC`;
    if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B CC`;
    if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M CC`;
    return `${value.toFixed(2)} CC`;
  };

  const marketCapBreakdown = [
    { category: 'Character Stocks', value: totalMarketCap * 0.45, percentage: 45, change: 2.8 },
    { category: 'Key Comics', value: totalMarketCap * 0.25, percentage: 25, change: 1.9 },
    { category: 'Creator Stocks', value: totalMarketCap * 0.15, percentage: 15, change: 3.2 },
    { category: 'Publisher Bonds', value: totalMarketCap * 0.08, percentage: 8, change: 0.8 },
    { category: 'Themed Funds', value: totalMarketCap * 0.05, percentage: 5, change: 1.5 },
    { category: 'Other Assets', value: totalMarketCap * 0.02, percentage: 2, change: 4.1 }
  ];

  const todaysEvents = [
    {
      time: '09:30 AM',
      event: 'Marvel Entertainment Q4 Earnings Beat',
      impact: 'Added $2.8B to character stock market cap',
      type: 'earnings',
      sentiment: 'positive'
    },
    {
      time: '11:15 AM',
      event: 'Spider-Man 4 Production Confirmed',
      impact: 'Spider-Man assets up $450M in market cap',
      type: 'announcement',
      sentiment: 'positive'
    },
    {
      time: '02:30 PM',
      event: 'DC Comics Restructuring News',
      impact: 'DC character stocks down $180M',
      type: 'corporate',
      sentiment: 'negative'
    },
    {
      time: '03:45 PM',
      event: 'Todd McFarlane Spawn Universe Deal',
      impact: 'Creator stocks surge, adding $320M',
      type: 'deal',
      sentiment: 'positive'
    }
  ];

  const upcomingIPOs = [
    {
      name: 'Sandman Universe Collection',
      symbol: 'SNDM',
      expectedValue: '$85M',
      date: 'July 15, 2025',
      type: 'Character Collection'
    },
    {
      name: 'Boom! Studios',
      symbol: 'BOOM',
      expectedValue: '$120M',
      date: 'June 30, 2025',
      type: 'Publisher'
    },
    {
      name: 'Golden Age Preservation Fund',
      symbol: 'GAPF',
      expectedValue: '$210M',
      date: 'July 1, 2025',
      type: 'Investment Fund'
    }
  ];

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'Market Capitalization' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <TrendingUp className="h-8 w-8 text-green-400" />
          <h1 className="text-3xl font-bold text-white">Market Capitalization Analysis</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Activity className="h-5 w-5" />
          <span className="text-sm">Live market data</span>
        </div>
      </div>

      {/* Total Market Cap Overview */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-4">Total Comic Market Capitalization</h2>
            <div className="flex items-center space-x-4 mb-4">
              <div>
                <p className="text-4xl font-bold text-white">{formatMarketCap(totalMarketCap)}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <span className="text-green-400 font-semibold">
                    +{formatMarketCap(marketCapChangeValue)} (+{marketCapChange}%)
                  </span>
                  <span className="text-gray-400">today</span>
                </div>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              The total market capitalization represents the combined value of all tradeable comic assets on the Panel Profits platform. 
              This includes character stocks, key comic issues, creator securities, publisher bonds, and investment funds. 
              Today's growth is driven by strong earnings reports and positive media announcements across multiple sectors.
            </p>
          </div>
          
          <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
            <h3 className="font-medium text-white mb-3">Market Composition</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Assets:</span>
                <span className="text-white">{liveMetrics?.totalAssetsCount || 291}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Active Traders:</span>
                <span className="text-white">{liveMetrics?.activeTradersCount || 2847}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Daily Volume:</span>
                <span className="text-white">{formatMarketCap((liveMetrics?.totalTrades || 8547) * 25000)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Hot Assets:</span>
                <span className="text-white">{liveMetrics?.hotAssetsCount || 87}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Market Cap Breakdown */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Market Cap by Asset Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {marketCapBreakdown.map((category, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 hover:shadow-lg transition-all">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-white">{category.category}</h3>
                <div className="flex items-center space-x-1">
                  {category.change > 0 ? (
                    <TrendingUp className="h-4 w-4 text-green-400" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-400" />
                  )}
                  <span className={`text-sm font-semibold ${category.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {category.change > 0 ? '+' : ''}{category.change}%
                  </span>
                </div>
              </div>
              <p className="text-2xl font-bold text-white mb-2">{formatMarketCap(category.value)}</p>
              <div className="w-full bg-slate-600 rounded-full h-2 mb-2">
                <div 
                  className="bg-indigo-500 h-2 rounded-full"
                  style={{ width: `${category.percentage}%` }}
                />
              </div>
              <p className="text-sm text-gray-400">{category.percentage}% of total market</p>
            </div>
          ))}
        </div>
      </div>

      {/* Today's Market Moving Events */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Today's Market Moving Events</h2>
        <div className="space-y-4">
          {todaysEvents.map((event, index) => (
            <div key={index} className={`p-4 rounded-lg border-l-4 ${
              event.sentiment === 'positive' ? 'border-l-green-500 bg-green-900/10' :
              event.sentiment === 'negative' ? 'border-l-red-500 bg-red-900/10' :
              'border-l-yellow-500 bg-yellow-900/10'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="text-sm font-medium text-gray-400">{event.time}</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      event.type === 'earnings' ? 'bg-blue-900/50 text-blue-200' :
                      event.type === 'announcement' ? 'bg-purple-900/50 text-purple-200' :
                      event.type === 'corporate' ? 'bg-orange-900/50 text-orange-200' :
                      'bg-green-900/50 text-green-200'
                    }`}>
                      {event.type.toUpperCase()}
                    </span>
                  </div>
                  <h3 className="font-semibold text-white mb-1">{event.event}</h3>
                  <p className="text-gray-300 text-sm">{event.impact}</p>
                </div>
                <div className="flex items-center space-x-1">
                  {event.sentiment === 'positive' ? (
                    <TrendingUp className="h-5 w-5 text-green-400" />
                  ) : event.sentiment === 'negative' ? (
                    <TrendingDown className="h-5 w-5 text-red-400" />
                  ) : (
                    <Activity className="h-5 w-5 text-yellow-400" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming IPOs */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Upcoming IPOs & Market Events</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingIPOs.map((ipo, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 hover:shadow-lg transition-all">
              <div className="flex items-center space-x-2 mb-3">
                <Building2 className="h-5 w-5 text-indigo-400" />
                <h3 className="font-medium text-white">{ipo.name}</h3>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Symbol:</span>
                  <span className="text-white font-medium">{ipo.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Expected Value:</span>
                  <span className="text-green-400 font-medium">{ipo.expectedValue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Launch Date:</span>
                  <span className="text-white">{ipo.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Type:</span>
                  <span className="text-indigo-400">{ipo.type}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Market Analysis */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Market Capitalization Analysis</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Key Insights</h3>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <Star className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-300 text-sm">
                  Character stocks dominate the market with 45% of total capitalization, reflecting strong investor confidence in superhero properties.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <Star className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-300 text-sm">
                  Key comics represent 25% of market cap, with Golden Age issues commanding premium valuations due to scarcity.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <Star className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-300 text-sm">
                  Creator stocks show highest volatility but also highest growth potential, currently 15% of total market.
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Market Drivers</h3>
            <div className="space-y-3">
              <div className="bg-green-900/30 p-3 rounded-lg border border-green-700/30">
                <h4 className="font-medium text-green-200 mb-1">Media Adaptations</h4>
                <p className="text-green-300 text-sm">Movie and TV announcements drive 60% of market cap increases</p>
              </div>
              <div className="bg-blue-900/30 p-3 rounded-lg border border-blue-700/30">
                <h4 className="font-medium text-blue-200 mb-1">Collector Demand</h4>
                <p className="text-blue-300 text-sm">Institutional collecting drives 25% of market growth</p>
              </div>
              <div className="bg-purple-900/30 p-3 rounded-lg border border-purple-700/30">
                <h4 className="font-medium text-purple-200 mb-1">Digital Innovation</h4>
                <p className="text-purple-300 text-sm">NFTs and digital ownership add 15% to market value</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent News Impact */}
      {news && news.length > 0 && (
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
          <h2 className="text-xl font-bold text-white mb-6">Recent News Impact on Market Cap</h2>
          <div className="space-y-4">
            {news.slice(0, 3).map((article) => (
              <div key={article.id} className={`p-4 rounded-lg border-l-4 ${
                article.impact === 'positive' ? 'border-l-green-500 bg-green-900/10' :
                article.impact === 'negative' ? 'border-l-red-500 bg-red-900/10' :
                'border-l-yellow-500 bg-yellow-900/10'
              }`}>
                <h3 className="font-semibold text-white mb-2">{article.title}</h3>
                <p className="text-gray-300 text-sm mb-2">{article.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-xs">{article.source}</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    article.impact === 'positive' ? 'bg-green-900/50 text-green-200' :
                    article.impact === 'negative' ? 'bg-red-900/50 text-red-200' :
                    'bg-yellow-900/50 text-yellow-200'
                  }`}>
                    {article.impact.toUpperCase()} IMPACT
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default MarketCapPage;