import React, { useState } from 'react';
import { Users, Activity, TrendingUp, TrendingDown, Clock, Target, BarChart2, Zap } from 'lucide-react';
import { Breadcrumbs } from '../../components/common/Breadcrumbs';
import { useSimulationStore } from '../../store/simulationStore';

export function DayTradersPage() {
  const { liveMetrics } = useSimulationStore();
  const [selectedTimeframe, setSelectedTimeframe] = useState('live');

  const activeDayTraders = liveMetrics?.activeTradersCount || 2847;
  const totalTraders = liveMetrics?.totalInvestors || 10000;
  const participationRate = (activeDayTraders / totalTraders) * 100;

  const traderCategories = [
    { 
      type: 'Scalpers', 
      count: Math.floor(activeDayTraders * 0.25), 
      description: 'Ultra-short-term traders holding positions for minutes',
      avgHoldTime: '< 5 minutes',
      profitability: 68,
      riskLevel: 'High'
    },
    { 
      type: 'Momentum Traders', 
      count: Math.floor(activeDayTraders * 0.35), 
      description: 'Follow trending assets and news-driven price movements',
      avgHoldTime: '2-4 hours',
      profitability: 72,
      riskLevel: 'Medium-High'
    },
    { 
      type: 'News Traders', 
      count: Math.floor(activeDayTraders * 0.20), 
      description: 'React to breaking news and announcements',
      avgHoldTime: '1-6 hours',
      profitability: 65,
      riskLevel: 'Medium'
    },
    { 
      type: 'Technical Traders', 
      count: Math.floor(activeDayTraders * 0.15), 
      description: 'Use charts and technical analysis for entries/exits',
      avgHoldTime: '3-8 hours',
      profitability: 74,
      riskLevel: 'Medium'
    },
    { 
      type: 'Arbitrage Traders', 
      count: Math.floor(activeDayTraders * 0.05), 
      description: 'Exploit price differences between related assets',
      avgHoldTime: '10-30 minutes',
      profitability: 82,
      riskLevel: 'Low-Medium'
    }
  ];

  const popularStrategies = [
    {
      strategy: 'Character Momentum',
      traders: 1247,
      description: 'Trading character stocks based on media announcements',
      winRate: 68,
      avgReturn: 12.5
    },
    {
      strategy: 'Comic Breakouts',
      traders: 892,
      description: 'Buying key comics on technical breakouts',
      winRate: 71,
      avgReturn: 15.8
    },
    {
      strategy: 'Creator Catalyst',
      traders: 654,
      description: 'Trading creator stocks on project announcements',
      winRate: 74,
      avgReturn: 18.2
    },
    {
      strategy: 'News Reaction',
      traders: 578,
      description: 'Quick trades on breaking comic industry news',
      winRate: 62,
      avgReturn: 9.8
    }
  ];

  const timeOfDayActivity = [
    { period: 'Market Open (9:30-10:30)', traders: Math.floor(activeDayTraders * 0.85), activity: 'Peak activity' },
    { period: 'Mid Morning (10:30-12:00)', traders: Math.floor(activeDayTraders * 0.65), activity: 'Moderate' },
    { period: 'Lunch Hour (12:00-13:00)', traders: Math.floor(activeDayTraders * 0.45), activity: 'Reduced' },
    { period: 'Afternoon (13:00-15:00)', traders: Math.floor(activeDayTraders * 0.70), activity: 'Increasing' },
    { period: 'Power Hour (15:00-16:00)', traders: Math.floor(activeDayTraders * 0.90), activity: 'Maximum' }
  ];

  return (
    <div className="space-y-6">
      <Breadcrumbs overrides={[
        { name: 'Markets', path: '/markets' },
        { name: 'Day Traders Analysis' }
      ]} />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Users className="h-8 w-8 text-orange-400" />
          <h1 className="text-3xl font-bold text-white">Day Traders Market Analysis</h1>
        </div>
        <div className="flex items-center space-x-2 text-gray-400">
          <Activity className="h-5 w-5" />
          <span className="text-sm">Live trader tracking</span>
        </div>
      </div>

      {/* Active Traders Overview */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-4">Active Day Traders</h2>
            <div className="flex items-center space-x-4 mb-4">
              <div>
                <p className="text-4xl font-bold text-white">{activeDayTraders.toLocaleString()}</p>
                <p className="text-gray-400">of {totalTraders.toLocaleString()} total investors</p>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="text-orange-400 font-semibold">
                    {participationRate.toFixed(1)}% market participation
                  </span>
                </div>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed">
              Day traders are active market participants who open and close positions within the same trading day. 
              They provide crucial market liquidity and help with price discovery, particularly during high-volatility periods 
              following news announcements or earnings reports. Current participation rates are above historical averages.
            </p>
          </div>
          
          <div className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
            <h3 className="font-medium text-white mb-3">Trader Activity</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Participation Rate:</span>
                <span className="text-white">{participationRate.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Trades/Trader:</span>
                <span className="text-white">{((liveMetrics?.totalTrades || 8547) / activeDayTraders).toFixed(1)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Success Rate:</span>
                <span className="text-white">71.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Daily Return:</span>
                <span className="text-green-400">+2.8%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trader Categories */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Day Trader Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {traderCategories.map((category, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50 hover:shadow-lg transition-all">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-white">{category.type}</h3>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  category.riskLevel === 'High' ? 'bg-red-900/50 text-red-200' :
                  category.riskLevel === 'Medium-High' ? 'bg-orange-900/50 text-orange-200' :
                  category.riskLevel === 'Medium' ? 'bg-yellow-900/50 text-yellow-200' :
                  'bg-green-900/50 text-green-200'
                }`}>
                  {category.riskLevel}
                </span>
              </div>
              <p className="text-2xl font-bold text-white mb-2">{category.count.toLocaleString()}</p>
              <p className="text-gray-300 text-sm mb-3">{category.description}</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <p className="text-gray-400">Hold Time</p>
                  <p className="text-white">{category.avgHoldTime}</p>
                </div>
                <div>
                  <p className="text-gray-400">Profitability</p>
                  <p className="text-green-400">{category.profitability}%</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Popular Strategies */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Most Popular Day Trading Strategies</h2>
        <div className="space-y-4">
          {popularStrategies.map((strategy, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="font-semibold text-white">{strategy.strategy}</h3>
                    <span className="text-gray-400">({strategy.traders.toLocaleString()} traders)</span>
                  </div>
                  <p className="text-gray-300 text-sm">{strategy.description}</p>
                </div>
                <div className="text-right">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-gray-400">Win Rate</p>
                      <p className="text-white font-medium">{strategy.winRate}%</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Avg Return</p>
                      <p className="text-green-400 font-medium">+{strategy.avgReturn}%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Time of Day Activity */}
      <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-6 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6">Day Trader Activity by Time</h2>
        <div className="space-y-3">
          {timeOfDayActivity.map((period, index) => (
            <div key={index} className="bg-slate-700/50 p-4 rounded-lg border border-slate-600/50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">{period.period}</h3>
                  <p className="text-gray-400 text-sm">{period.activity} trading activity</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">{period.traders.toLocaleString()}</p>
                  <p className="text-gray-400 text-sm">active traders</p>
                </div>
              </div>
              <div className="mt-2">
                <div className="w-full bg-slate-600 rounded-full h-2">
                  <div 
                    className="bg-orange-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(period.traders / activeDayTraders) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default DayTradersPage;