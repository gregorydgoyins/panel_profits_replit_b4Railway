import React from 'react';
import { FundDetails } from '../../components/fund/FundDetails';

export function FundDetailsPage() {
  return <FundDetails />;
}

export default FundDetailsPage;