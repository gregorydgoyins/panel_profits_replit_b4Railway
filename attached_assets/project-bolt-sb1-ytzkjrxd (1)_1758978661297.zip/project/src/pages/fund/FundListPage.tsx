import React from 'react';
import { FundList } from '../../components/fund/FundList';

export function FundListPage() {
  return <FundList />;
}

export default FundListPage;