import React, { Suspense, lazy, useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { Layout } from './components/Layout';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { Loader } from './components/common/Loader';
import { NewsTicker } from './components/news/NewsTicker';
import { NewsNotification } from './components/news/NewsNotification';
import { StockTicker } from './components/tickers/StockTicker';
import { GlobalMarketClocks } from './components/common/GlobalMarketClocks';
import { QuarterlyReportsModule } from './modules/QuarterlyReportsModule';
import { GlobalMarketClocksModule } from './modules/GlobalMarketClocksModule';
import { useSimulationStore } from './store/simulationStore';
import { LiveMarketIntelligenceHub } from './components/navigation/LiveMarketIntelligenceHub';
import { TradingDeskHub } from './components/navigation/TradingDeskHub';
import { LearningResearchHub } from './components/navigation/LearningResearchHub';
import { MarketStatisticsDashboard } from './components/navigation/MarketStatisticsDashboard';
import MarketCapPage from './pages/markets/MarketCapPage';
import FearGreedIndexPage from './pages/markets/FearGreedIndexPage';
import CreatorBiosPage from './pages/creator/CreatorBiosPage';
import { VolumeAnalysisPage } from './pages/markets/VolumeAnalysisPage';
import { DayTradersPage } from './pages/markets/DayTradersPage';
import { AIConfidencePage } from './pages/markets/AIConfidencePage';
import { HotAssetsPage } from './pages/markets/HotAssetsPage';
import { TradingViewPage } from './pages/trading/TradingViewPage';
import { HeroCarousel } from './components/HeroCarousel';
import { 
  TrendingUp, TrendingDown, Activity, Crown, BarChart2, Globe,
  Home, DollarSign, Newspaper, Briefcase, Brain, LineChart, Layers, Compass, Zap, Star,
  ShoppingCart, PieChart, Calculator, Target, Shield, AlertTriangle, BookOpen, Users, FileText,
  User, GraduationCap, Calendar
} from 'lucide-react';

// Main components
import { Dashboard } from './components/Dashboard';

// Lazy loaded pages
const IdeasPage = lazy(() => import('./pages/IdeasPage').then(module => ({ default: module.IdeasPage })));
const IdeaMappingPage = lazy(() => import('./pages/IdeaMappingPage').then(module => ({ default: module.IdeaMappingPage })));
const KeyComicsPage = lazy(() => import('./pages/KeyComicsPage').then(module => ({ default: module.KeyComicsPage })));

// Trading pages
const TradingPage = lazy(() => import('./pages/trading/TradingPage').then(module => ({ default: module.TradingPage })));
const BuyPage = lazy(() => import('./pages/trading/BuyPage').then(module => ({ default: module.BuyPage })));
const SellPage = lazy(() => import('./pages/trading/SellPage').then(module => ({ default: module.SellPage })));
const ETFsPage = lazy(() => import('./pages/trading/ETFsPage').then(module => ({ default: module.ETFsPage })));

// Character pages
const CharacterStockPage = lazy(() => import('./pages/character/CharacterStockPage').then(module => ({ default: module.CharacterStockPage })));
const HeroStockPage = lazy(() => import('./pages/character/HeroStockPage').then(module => ({ default: module.HeroStockPage })));
const VillainStockPage = lazy(() => import('./pages/character/VillainStockPage').then(module => ({ default: module.VillainStockPage })));
const SidekickStockPage = lazy(() => import('./pages/character/SidekickStockPage').then(module => ({ default: module.SidekickStockPage })));
const HenchmanStockPage = lazy(() => import('./pages/character/HenchmanStockPage').then(module => ({ default: module.HenchmanStockPage })));
const CharacterDetailsPage = lazy(() => import('./pages/character/CharacterDetailsPage').then(module => ({ default: module.CharacterDetailsPage })));

// Creator pages
const CreatorMatrix = lazy(() => import('./components/creator/CreatorMatrix').then(module => ({ default: module.CreatorMatrix })));
const CreatorProfile = lazy(() => import('./components/creator/CreatorProfile').then(module => ({ default: module.CreatorProfile })));

// Location pages
const LocationStockPage = lazy(() => import('./pages/location/LocationStockPage').then(module => ({ default: module.LocationStockPage })));
const HangoutStockPage = lazy(() => import('./pages/location/HangoutStockPage').then(module => ({ default: module.HangoutStockPage })));
const HideoutStockPage = lazy(() => import('./pages/location/HideoutStockPage').then(module => ({ default: module.HideoutStockPage })));
const LocationDetailsPage = lazy(() => import('./pages/location/LocationDetailsPage').then(module => ({ default: module.LocationDetailsPage })));

// Gadget pages
const GadgetStockPage = lazy(() => import('./pages/gadget/GadgetStockPage').then(module => ({ default: module.GadgetStockPage })));
const GadgetDetailsPage = lazy(() => import('./pages/gadget/GadgetDetailsPage').then(module => ({ default: module.GadgetDetailsPage })));

// Bond pages
const BondListPage = lazy(() => import('./pages/bond/BondListPage').then(module => ({ default: module.BondListPage })));
const CreatorBondPage = lazy(() => import('./pages/bond/CreatorBondPage').then(module => ({ default: module.CreatorBondPage })));
const PublisherBondPage = lazy(() => import('./pages/bond/PublisherBondPage').then(module => ({ default: module.PublisherBondPage })));
const SpecialtyBondPage = lazy(() => import('./pages/bond/SpecialtyBondPage').then(module => ({ default: module.SpecialtyBondPage })));
const BondDetailsPage = lazy(() => import('./pages/bond/BondDetailsPage').then(module => ({ default: module.BondDetailsPage })));

// Fund pages
const FundListPage = lazy(() => import('./pages/fund/FundListPage').then(module => ({ default: module.FundListPage })));
const ThemedFundPage = lazy(() => import('./pages/fund/ThemedFundPage').then(module => ({ default: module.ThemedFundPage })));
const CustomFundPage = lazy(() => import('./pages/fund/CustomFundPage').then(module => ({ default: module.CustomFundPage })));
const FundDetailsPage = lazy(() => import('./pages/fund/FundDetailsPage').then(module => ({ default: module.FundDetailsPage })));

// Portfolio pages
const WatchlistPage = lazy(() => import('./pages/portfolio/WatchlistPage').then(module => ({ default: module.WatchlistPage })));
const TradingJournalPage = lazy(() => import('./pages/portfolio/TradingJournalPage').then(module => ({ default: module.TradingJournalPage })));
const ToolsPage = lazy(() => import('./pages/portfolio/ToolsPage').then(module => ({ default: module.ToolsPage })));
const FormulasPage = lazy(() => import('./pages/portfolio/FormulasPage').then(module => ({ default: module.FormulasPage })));

// Options trading pages
const CallsPage = lazy(() => import('./pages/trading/options/CallsPage').then(module => ({ default: module.CallsPage })));
const PutsPage = lazy(() => import('./pages/trading/options/PutsPage').then(module => ({ default: module.PutsPage })));
const LEAPsPage = lazy(() => import('./pages/trading/options/LEAPsPage').then(module => ({ default: module.LEAPsPage })));

// Specialty trading pages
const StraddlesPage = lazy(() => import('./pages/trading/specialty/StraddlesPage').then(module => ({ default: module.StraddlesPage })));
const ButterflysPage = lazy(() => import('./pages/trading/specialty/ButterflysPage').then(module => ({ default: module.ButterflysPage })));
const BullBearStraddlesPage = lazy(() => import('./pages/trading/specialty/BullBearStraddlesPage').then(module => ({ default: module.BullBearStraddlesPage })));
const DerivativesFuturesPage = lazy(() => import('./pages/trading/DerivativesFuturesPage').then(module => ({ default: module.DerivativesFuturesPage })));

// Market pages
const MarketCalendarPage = lazy(() => import('./pages/markets/MarketCalendarPage').then(module => ({ default: module.MarketCalendarPage })));

// Learning pages
const LearningCenter = lazy(() => import('./components/learn/LearningCenter').then(module => ({ default: module.LearningCenter })));
const ComicFundamentalsCoursePage = lazy(() => import('./pages/learn/ComicFundamentalsCoursePage').then(module => ({ default: module.ComicFundamentalsCoursePage })));
const AdvancedOptionsCoursePage = lazy(() => import('./pages/learn/AdvancedOptionsCoursePage').then(module => ({ default: module.AdvancedOptionsCoursePage })));
const PortfolioManagementCoursePage = lazy(() => import('./pages/learn/PortfolioManagementCoursePage').then(module => ({ default: module.PortfolioManagementCoursePage })));

// Technical Analysis pages
const TechnicalAnalysisStudioPage = lazy(() => import('./pages/TechnicalAnalysisStudioPage').then(module => ({ default: module.TechnicalAnalysisStudioPage })));

// News pages
const BlogFeed = lazy(() => import('./components/news/BlogFeed').then(module => ({ default: module.BlogFeed })));
const NewsFeed = lazy(() => import('./components/news/NewsFeed').then(module => ({ default: module.NewsFeed })));
const NewsDetailPage = lazy(() => import('./pages/news/NewsDetailPage').then(module => ({ default: module.NewsDetailPage })));
const NewsManagement = lazy(() => import('./components/news/NewsManagement').then(module => ({ default: module.NewsManagement })));

// Research pages
const ResearchReport = lazy(() => import('./components/research/ResearchReport').then(module => ({ default: module.ResearchReport })));

// Auth pages
const Login = lazy(() => import('./components/auth/Login').then(module => ({ default: module.Login })));
const Register = lazy(() => import('./components/auth/Register').then(module => ({ default: module.Register })));
const ForgotPassword = lazy(() => import('./components/auth/ForgotPassword').then(module => ({ default: module.ForgotPassword })));
const ResetPassword = lazy(() => import('./components/auth/ResetPassword').then(module => ({ default: module.ResetPassword })));
const UserProfile = lazy(() => import('./components/auth/UserProfile').then(module => ({ default: module.UserProfile })));

// Navigation testing
const NavigationTest = lazy(() => import('./components/navigation/NavigationTest').then(module => ({ default: module.NavigationTest })));

// Video testing
const VideoTestPage = lazy(() => import('./components/VideoTestPage').then(module => ({ default: module.VideoTestPage })));

// Simulation page
const SimulationPage = lazy(() => import('./pages/SimulationPage').then(module => ({ default: module.SimulationPage })));

// Loading fallback
const PageLoader = () => <Loader />;

function App() {
  const location = useLocation();
  const { liveMetrics, marketState, isRunning } = useSimulationStore();
  const [tickerSpeedMultiplier, setTickerSpeedMultiplier] = React.useState(1);
  
  // Calculate overall market sentiment from simulation data
  const marketSentiment = liveMetrics?.avgReturn || 0.025; // Default positive sentiment
  const marketIndex = 14250 + (marketSentiment * 1000); // Fluctuates based on sentiment
  const sentimentPercentage = Math.abs(marketSentiment * 100);
  const isMarketPositive = marketSentiment > 0;
  
  // Calculate dynamic scroll duration based on speed multiplier
  const baseDuration = 389; // Base duration in seconds (20% slower)
  const scrollDuration = `${Math.round(baseDuration / tickerSpeedMultiplier)}s`;
  
  return (
    <ErrorBoundary>
      <>
      {/* News Ticker Platform */}
      <div className="bg-slate-700 p-2 mx-4 mt-2 mb-4 rounded-xl">
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-2 shadow-xl border border-blue-500 hover:shadow-[0_0_25px_rgba(59,130,246,0.8)] hover:border-blue-400 hover:border-2 transition-all">
        <NewsTicker maxItems={50} scrollDuration="450s" />
        </div>
      </div>
      
      {/* Stock Ticker Platform */}
      <div className="bg-slate-700 p-2 mx-4 mt-2 mb-4 rounded-xl">
        <div className="bg-slate-800/90 backdrop-blur-md rounded-xl p-2 shadow-xl border border-green-500 hover:shadow-[0_0_25px_rgba(34,197,94,0.8)] hover:border-green-400 hover:border-2 transition-all">
        <StockTicker 
          maxAssets={350} 
          speed={0.0225} 
          showControls={true} 
          scrollDuration={scrollDuration}
          speedMultiplier={tickerSpeedMultiplier}
          onSpeedChange={setTickerSpeedMultiplier}
        />
        </div>
      </div>
      
      {/* Market Statistics Dashboard */}
      <div className="mx-4 mb-4">
        <MarketStatisticsDashboard />
      </div>
      
      {/* Hero Carousel */}
      <div className="mx-4 mb-4">
        <HeroCarousel />
      </div>
      
      {/* Trading Desk Hub */}
      <div className="mx-4 mb-4">
        <TradingDeskHub />
      </div>
      
      {/* Live Market Intelligence Hub */}
      <div className="mx-4 mb-4">
        <LiveMarketIntelligenceHub />
      </div>
      
      {/* Learning & Research Hub */}
      <div className="mx-4 mb-4">
        <LearningResearchHub />
      </div>
      
      {/* Global Market Clocks */}
      <div className="bg-slate-700 p-2 mx-4 mt-2 mb-4 rounded-xl">
        <GlobalMarketClocksModule />
      </div>
      
      {/* Quarterly Reports Calendar */}
      <div className="bg-slate-700 p-2 mx-4 mt-2 mb-4 rounded-xl">
        <QuarterlyReportsModule />
      </div>
      
      <Layout>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            {/* Main Dashboard */}
            <Route path="/" element={<Dashboard />} />
            
            {/* Ideas Routes */}
            <Route path="/ideas" element={<IdeasPage />} />
            <Route path="/ideas/mapping" element={<IdeaMappingPage />} />
            <Route path="/key-comics" element={<KeyComicsPage />} />
            <Route path="/technical-analysis" element={<TechnicalAnalysisStudioPage />} />
            
            {/* Simulation Route */}
            <Route path="/simulation" element={<SimulationPage />} />
            
            {/* Trading Routes */}
            <Route path="/trading" element={<TradingPage />} />
            <Route path="/trading/buy" element={<BuyPage />} />
            <Route path="/trading/sell" element={<SellPage />} />
            <Route path="/trading/etfs" element={<ETFsPage />} />
            
            {/* Options Trading */}
            <Route path="/trading/options/calls" element={<CallsPage />} />
            <Route path="/trading/options/puts" element={<PutsPage />} />
            <Route path="/trading/options/leaps" element={<LEAPsPage />} />
            
            {/* Specialty Trading */}
            <Route path="/trading/specialty/straddles" element={<StraddlesPage />} />
            <Route path="/trading/specialty/butterflys" element={<ButterflysPage />} />
            <Route path="/trading/specialty/bull-bear-straddles" element={<BullBearStraddlesPage />} />
            <Route path="/trading/derivatives-futures" element={<DerivativesFuturesPage />} />
            
            {/* Character Routes */}
            <Route path="/characters" element={<CharacterStockPage />} />
            <Route path="/characters/heroes" element={<HeroStockPage />} />
            <Route path="/characters/villains" element={<VillainStockPage />} />
            <Route path="/characters/sidekicks" element={<SidekickStockPage />} />
            <Route path="/characters/henchmen" element={<HenchmanStockPage />} />
            <Route path="/character/:symbol" element={<CharacterDetailsPage />} />
            <Route path="/hero/:symbol" element={<CharacterDetailsPage />} />
            <Route path="/villain/:symbol" element={<CharacterDetailsPage />} />
            <Route path="/sidekick/:symbol" element={<CharacterDetailsPage />} />
            <Route path="/henchman/:symbol" element={<CharacterDetailsPage />} />
            
            {/* Creator Routes */}
            <Route path="/creators" element={<CreatorMatrix />} />
            <Route path="/creator/:symbol" element={<CreatorProfile />} />
            <Route path="/creator-stock/:symbol" element={<CreatorProfile />} />
            <Route path="/creators/bios" element={<CreatorBiosPage />} />
            
            {/* Location Routes */}
            <Route path="/locations" element={<LocationStockPage />} />
            <Route path="/locations/hangouts" element={<HangoutStockPage />} />
            <Route path="/locations/hideouts" element={<HideoutStockPage />} />
            <Route path="/location/:symbol" element={<LocationDetailsPage />} />
            <Route path="/hangout/:symbol" element={<LocationDetailsPage />} />
            <Route path="/hideout/:symbol" element={<LocationDetailsPage />} />
            
            {/* Gadget Routes */}
            <Route path="/gadgets" element={<GadgetStockPage />} />
            <Route path="/gadget/:symbol" element={<GadgetDetailsPage />} />
            
            {/* Bond Routes */}
            <Route path="/bonds" element={<BondListPage />} />
            <Route path="/bonds/creator" element={<CreatorBondPage />} />
            <Route path="/bonds/publisher" element={<PublisherBondPage />} />
            <Route path="/bonds/specialty" element={<SpecialtyBondPage />} />
            <Route path="/bond/:symbol" element={<BondDetailsPage />} />
            
            {/* Fund Routes */}
            <Route path="/funds" element={<FundListPage />} />
            <Route path="/funds/themed" element={<ThemedFundPage />} />
            <Route path="/funds/custom" element={<CustomFundPage />} />
            <Route path="/fund/:symbol" element={<FundDetailsPage />} />
            
            {/* Portfolio Routes */}
            <Route path="/portfolio" element={<WatchlistPage />} />
            <Route path="/portfolio/watchlist" element={<WatchlistPage />} />
            <Route path="/portfolio/journal" element={<TradingJournalPage />} />
            <Route path="/portfolio/tools" element={<ToolsPage />} />
            <Route path="/portfolio/formulas" element={<FormulasPage />} />
            
            {/* Market Routes */}
            <Route path="/markets" element={<MarketCalendarPage />} />
            <Route path="/markets" element={<MarketCalendarPage />} />
            <Route path="/markets/calendar" element={<MarketCalendarPage />} />
            <Route path="/markets/market-cap" element={<MarketCapPage />} />
            <Route path="/markets/fear-greed-index" element={<FearGreedIndexPage />} />
            <Route path="/markets/volume-analysis" element={<VolumeAnalysisPage />} />
            <Route path="/markets/day-traders" element={<DayTradersPage />} />
            <Route path="/markets/ai-confidence" element={<AIConfidencePage />} />
            <Route path="/markets/hot-assets" element={<HotAssetsPage />} />
            <Route path="/trading/trading-view" element={<TradingViewPage />} />
            
            {/* Learning Routes */}
            <Route path="/learn" element={<LearningCenter />} />
            <Route path="/learn/comic-fundamentals" element={<ComicFundamentalsCoursePage />} />
            <Route path="/learn/advanced-options" element={<AdvancedOptionsCoursePage />} />
            <Route path="/learn/portfolio-management" element={<PortfolioManagementCoursePage />} />
            
            {/* News Routes */}
            <Route path="/news" element={<NewsFeed />} />
            <Route path="/news/:id" element={<NewsDetailPage />} />
            <Route path="/news/manage" element={<NewsManagement userRole="admin" />} />
            <Route path="/blog" element={<BlogFeed />} />
            
            {/* Research Routes */}
            <Route path="/research" element={<ResearchReport />} />
            
            {/* Technical Analysis Routes */}
            <Route path="/technical-analysis" element={<TechnicalAnalysisStudioPage />} />
            
            {/* Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/profile" element={<UserProfile />} />
            
            {/* Testing Routes */}
            <Route path="/navigation-test" element={<NavigationTest />} />
            <Route path="/video-test" element={<VideoTestPage />} />
            
            {/* Catch all route */}
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </Suspense>
      </Layout>
      </>
    </ErrorBoundary>
  );
}

export default App;